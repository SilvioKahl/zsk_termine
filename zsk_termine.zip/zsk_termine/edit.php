<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use local_zsk_termine\form\event_form;

require_login();
local_zsk_termine_require_manage();

$id = optional_param('id', 0, PARAM_INT);

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_termine/edit.php', ['id' => $id]));
$PAGE->set_pagelayout('admin');

$categories = local_zsk_termine_get_categories();
$catoptions = [];
foreach ($categories as $cat) {
    $catoptions[$cat->id] = format_string($cat->name);
}
if (empty($catoptions)) {
    throw new moodle_exception('no_categories', 'local_zsk_termine');
}

$event = null;
if ($id > 0) {
    $event = local_zsk_termine_get_event($id);
    if (!$event) {
        throw new moodle_exception('invalidevent', 'local_zsk_termine');
    }
    $PAGE->set_title(get_string('edit_event', 'local_zsk_termine'));
    $PAGE->set_heading(get_string('edit_event', 'local_zsk_termine'));
} else {
    $PAGE->set_title(get_string('add_event', 'local_zsk_termine'));
    $PAGE->set_heading(get_string('add_event', 'local_zsk_termine'));
}

$form = new event_form(null, [
    'categories' => $catoptions,
    'isnew' => ($id === 0),
    'notifyenabled' => local_zsk_termine_notifications_enabled(),
    'canhighlight' => \local_zsk_termine\util\license::can_use_highlighted_events(),
    'cannotifyall' => \local_zsk_termine\util\license::can_notify_all_users(),
]);

if ($event) {
    $data = (object) [
        'id' => $event->id,
        'title' => $event->title,
        'categoryid' => $event->categoryid,
        'timestart' => $event->timestart,
        'timeend' => $event->timeend ?: 0,
        'hasend' => !empty($event->timeend),
        'location' => $event->location,
        'description' => $event->description,
        'descriptionformat' => $event->descriptionformat,
        'cancelled' => $event->cancelled,
        'highlighted' => !empty($event->highlighted) && \local_zsk_termine\util\license::can_use_highlighted_events(),
        'courseid' => (int) ($event->courseid ?? 0),
    ];
    $data->description = ['text' => $event->description, 'format' => $event->descriptionformat];
    $form->set_data($data);
}

if ($form->is_cancelled()) {
    redirect(new moodle_url('/local/zsk_termine/events.php'));
}

if ($data = $form->get_data()) {
    global $DB, $USER;

    $record = (object) [
        'categoryid' => (int) $data->categoryid,
        'title' => $data->title,
        'location' => $data->location ?? '',
        'timestart' => (int) $data->timestart,
        'timeend' => !empty($data->hasend) ? (int) $data->timeend : 0,
        'cancelled' => empty($data->cancelled) ? 0 : 1,
        'highlighted' => (!empty($data->highlighted) && \local_zsk_termine\util\license::can_use_highlighted_events()) ? 1 : 0,
        'courseid' => max(0, (int) ($data->courseid ?? 0)),
        'timemodified' => time(),
        'usermodified' => $USER->id,
    ];

    $record->description = $data->description['text'] ?? '';
    $record->descriptionformat = $data->description['format'] ?? FORMAT_HTML;

    if ($id > 0) {
        $record->id = $id;
        $DB->update_record('local_zsk_termine_event', $record);
        $eventid = $id;
        \local_zsk_termine\webhook\dispatcher::dispatch($eventid, \local_zsk_termine\webhook\dispatcher::ACTION_UPDATED);
    } else {
        $record->timecreated = time();
        $record->remindersent = 0;
        $eventid = (int) $DB->insert_record('local_zsk_termine_event', $record);
        \local_zsk_termine\webhook\dispatcher::dispatch($eventid, \local_zsk_termine\webhook\dispatcher::ACTION_CREATED);
    }

    $notifyqueued = 0;
    if ($id === 0 && !empty($data->sendnotification) && empty($data->cancelled)) {
        $audience = \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ALL;
        if (!empty($record->courseid) && !empty($data->notifyaudience)) {
            $audience = (string) $data->notifyaudience;
        }
        $notifyqueued = local_zsk_termine_queue_event_notification($eventid, $audience);
    }

    if (!empty($record->courseid)) {
        local_zsk_termine_invalidate_course_display((int) $record->courseid);
    }
    if ($id > 0 && !empty($event->courseid) && (int) $event->courseid !== (int) $record->courseid) {
        local_zsk_termine_invalidate_course_display((int) $event->courseid);
    }

    if ($notifyqueued > 0) {
        $message = get_string('event_saved_notify_queued', 'local_zsk_termine', $notifyqueued);
    } else {
        $message = get_string('event_saved', 'local_zsk_termine');
    }

    redirect(
        new moodle_url('/local/zsk_termine/events.php'),
        $message,
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

echo $OUTPUT->header();
echo html_writer::div(
    html_writer::link(new moodle_url('/local/zsk_termine/events.php'), '« ' . get_string('manage_events_list', 'local_zsk_termine')),
    'mb-3'
);
$form->display();
echo $OUTPUT->footer();
