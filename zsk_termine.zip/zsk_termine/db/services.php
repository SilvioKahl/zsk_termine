<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_zsk_termine_get_events' => [
        'classname' => 'local_zsk_termine\external\get_events',
        'methodname' => 'execute',
        'classpath' => '',
        'description' => 'List upcoming ZSK Termine events (Pro).',
        'type' => 'read',
        'capabilities' => 'local/zsk_termine:view',
        'services' => ['zsk_termine'],
    ],
    'local_zsk_termine_get_ical' => [
        'classname' => 'local_zsk_termine\external\get_ical',
        'methodname' => 'execute',
        'classpath' => '',
        'description' => 'Get iCal feed for calendar subscription (Pro).',
        'type' => 'read',
        'capabilities' => 'local/zsk_termine:view',
        'services' => ['zsk_termine'],
    ],
];

$services = [
    'ZSK Termine API' => [
        'shortname' => 'zsk_termine',
        'functions' => [
            'local_zsk_termine_get_events',
            'local_zsk_termine_get_ical',
        ],
        'enabled' => 1,
        'restrictedusers' => 0,
        'downloadfiles' => 0,
        'uploadfiles' => 0,
    ],
];
