<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Copy data from legacy local_termine tables and config if present.
 *
 * @return void
 */
function local_zsk_termine_migrate_legacy_plugin_data(): void {
    global $DB;

    $dbman = $DB->get_manager();
    $pairs = [
        'local_termine_category' => 'local_zsk_termine_category',
        'local_termine_event' => 'local_zsk_termine_event',
        'local_termine_allow_manage' => 'local_zsk_termine_allow_manage',
    ];

    foreach ($pairs as $legacytable => $newtable) {
        if (!$dbman->table_exists($legacytable) || !$dbman->table_exists($newtable)) {
            continue;
        }
        foreach ($DB->get_records($legacytable) as $record) {
            if ($DB->record_exists($newtable, ['id' => $record->id])) {
                continue;
            }
            $DB->insert_record($newtable, $record);
        }
    }

    $configkeys = [
        'block_dashboard',
        'block_frontpage',
        'block_preview_count',
        'block_position',
        'accessmode',
    ];

    foreach ($configkeys as $key) {
        $value = get_config('local_termine', $key);
        if ($value !== false && $value !== null && get_config('local_zsk_termine', $key) === false) {
            set_config($key, $value, 'local_zsk_termine');
        }
    }

    $capmap = [
        'local/termine:view' => 'local/zsk_termine:view',
        'local/termine:manage' => 'local/zsk_termine:manage',
    ];

    foreach ($capmap as $oldcap => $newcap) {
        $records = $DB->get_records('role_capabilities', ['capability' => $oldcap]);
        foreach ($records as $record) {
            if ($DB->record_exists('role_capabilities', [
                'roleid' => $record->roleid,
                'capability' => $newcap,
                'contextid' => $record->contextid,
            ])) {
                continue;
            }
            $record->capability = $newcap;
            $DB->update_record('role_capabilities', $record);
        }
    }

    if (class_exists(\local_zsk_termine\dashboard_block::class)) {
        \local_zsk_termine\dashboard_block::remove_legacy_block_instances();
    }
}

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_zsk_termine_upgrade(int $oldversion): bool {
    if ($oldversion < 2025060700) {
        local_zsk_termine_migrate_legacy_plugin_data();
        upgrade_plugin_savepoint(true, 2025060700, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025060900) {
        upgrade_plugin_savepoint(true, 2025060900, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061000) {
        upgrade_plugin_savepoint(true, 2025061000, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061002) {
        $sharedurl = get_config('local_zsk_plugins', 'license_server_url');
        if ($sharedurl === false || $sharedurl === '') {
            $legacyurl = get_config('local_zsk_termine', 'license_server_url');
            if (!empty($legacyurl)) {
                set_config('license_server_url', $legacyurl, 'local_zsk_plugins');
            }
        }
        $sharedgrace = get_config('local_zsk_plugins', 'license_grace_days');
        if ($sharedgrace === false || $sharedgrace === '') {
            $legacygrace = get_config('local_zsk_termine', 'license_grace_days');
            if ($legacygrace !== false && $legacygrace !== '') {
                set_config('license_grace_days', $legacygrace, 'local_zsk_plugins');
            }
        }
        upgrade_plugin_savepoint(true, 2025061002, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061003) {
        upgrade_plugin_savepoint(true, 2025061003, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061100) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_termine_event');
        $field = new xmldb_field('remindersent', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'usermodified');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $table = new xmldb_table('local_zsk_termine_category_lang');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
        $table->add_field('categoryid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('lang', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL);
        $table->add_field('notify_subject', XMLDB_TYPE_CHAR, '255');
        $table->add_field('notify_bodyhtml', XMLDB_TYPE_TEXT);
        $table->add_field('notify_bodyplain', XMLDB_TYPE_TEXT);
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('category_lang_uq', XMLDB_KEY_UNIQUE, ['categoryid', 'lang']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        $table = new xmldb_table('local_zsk_termine_notify_log');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
        $table->add_field('eventid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('sendtype', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'new');
        $table->add_field('tracktoken', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL);
        $table->add_field('timesent', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('opened', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('openedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('clicked', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('clickedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('tracktoken_uq', XMLDB_KEY_UNIQUE, ['tracktoken']);
        $table->add_index('event_user_ix', XMLDB_INDEX_NOTUNIQUE, ['eventid', 'userid']);
        $table->add_index('sendtype_ix', XMLDB_INDEX_NOTUNIQUE, ['sendtype']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        $table = new xmldb_table('local_zsk_termine_stat');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
        $table->add_field('eventid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('action', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_index('event_action_ix', XMLDB_INDEX_NOTUNIQUE, ['eventid', 'action']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2025061100, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061101) {
        upgrade_plugin_savepoint(true, 2025061101, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061102) {
        upgrade_plugin_savepoint(true, 2025061102, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061103) {
        upgrade_plugin_savepoint(true, 2025061103, 'local', 'zsk_termine');
    }

    if ($oldversion < 2025061104) {
        upgrade_plugin_savepoint(true, 2025061104, 'local', 'zsk_termine');
    }

    return true;
}
