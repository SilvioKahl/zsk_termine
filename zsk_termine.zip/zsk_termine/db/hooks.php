<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook' => \core\hook\output\before_footer_html_generation::class,
        'callback' => [\local_zsk_termine\hook_callbacks::class, 'inject_upcoming_block'],
        'priority' => 500,
    ],
    [
        'hook' => \core\hook\navigation\primary_extend::class,
        'callback' => [\local_zsk_termine\hook_callbacks::class, 'extend_primary_navigation'],
    ],
];

if (class_exists(\core\hook\output\before_standard_head_html_generation::class)) {
    $callbacks[] = [
        'hook' => \core\hook\output\before_standard_head_html_generation::class,
        'callback' => [\local_zsk_termine\hook_callbacks::class, 'register_page_styles'],
    ];
}
