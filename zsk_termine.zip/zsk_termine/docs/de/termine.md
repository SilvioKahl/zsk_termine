# ZSK Termine (`local_zsk_termine` + `mod_zsktermine`)

## Installation

1. Ordner `local/zsk_termine` und `mod/zsktermine` nach Moodle kopieren.
2. Als Administrator: **Website-Administration → Benachrichtigungen** (Plugin-Upgrade).
3. Caches leeren.

**Zwei Plugins:** `local_zsk_termine` (Pflege & Anzeige) und `mod_zsktermine` (Kursaktivität). Kein Block-Plugin nötig.

## Anzeige auf Startseite / Dashboard / Meine Kurse

**Website-Administration → Darstellung → Startseite & Dashboard**

## Web-Services / REST-API (Pro)

Siehe [webservices.md](webservices.md) – Schritt-für-Schritt inkl. Token-Anlage und `curl`-Test.

## Migration

Siehe [MIGRATION.md](../MIGRATION.md).
