<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');

$action = optional_param('action', 'open', PARAM_ALPHA);
$token = required_param('t', PARAM_ALPHANUMEXT);
$url = optional_param('url', '', PARAM_RAW);

\local_zsk_termine\notification\tracker::record_action($token, $action);

if ($action === 'click' && $url !== '') {
    $cleanurl = clean_param($url, PARAM_URL);
    if ($cleanurl !== '') {
        redirect(new moodle_url($cleanurl));
    }
}

header('Content-Type: image/gif');
header('Cache-Control: no-store, no-cache, must-revalidate');
echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
die();
