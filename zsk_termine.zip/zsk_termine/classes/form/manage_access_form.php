<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class manage_access_form extends \moodleform {

    protected function definition() {
        $mform = $this->_form;

        $mform->addElement('header', 'accessheading', get_string('manageaccess', 'local_zsk_termine'));
        $mform->addElement('static', 'desc', '', get_string('manageaccess_desc', 'local_zsk_termine'));

        $useroptions = $this->_customdata['useroptions'] ?? [];
        $mform->addElement('autocomplete', 'allowmanageusers', get_string('allowmanageusers', 'local_zsk_termine'), $useroptions, [
            'multiple' => true,
            'ajax' => 'core_user/form_user_selector',
        ]);
        $mform->addHelpButton('allowmanageusers', 'allowmanageusers', 'local_zsk_termine');

        $this->add_action_buttons(true, get_string('savechanges'));
    }
}
