<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class event_form extends \moodleform {

    protected function definition() {
        $mform = $this->_form;
        $categories = $this->_customdata['categories'] ?? [];
        $isnew = !empty($this->_customdata['isnew']);
        $notifyenabled = !empty($this->_customdata['notifyenabled']);
        $canhighlight = !empty($this->_customdata['canhighlight']);
        $cannotifyall = !empty($this->_customdata['cannotifyall']);

        $mform->addElement('hidden', 'id', 0);
        $mform->setType('id', PARAM_INT);

        $mform->addElement('text', 'title', get_string('event_title', 'local_zsk_termine'), ['size' => 64]);
        $mform->setType('title', PARAM_TEXT);
        $mform->addRule('title', null, 'required');

        $mform->addElement('select', 'categoryid', get_string('event_category', 'local_zsk_termine'), $categories);
        $mform->addRule('categoryid', null, 'required');

        $mform->addElement(
            'select',
            'courseid',
            get_string('event_course', 'local_zsk_termine'),
            \local_zsk_termine_get_course_options()
        );
        $mform->addHelpButton('courseid', 'event_course', 'local_zsk_termine');

        $mform->addElement('date_time_selector', 'timestart', get_string('event_timestart', 'local_zsk_termine'));
        $mform->addRule('timestart', null, 'required');

        $mform->addElement('advcheckbox', 'hasend', get_string('event_hasend', 'local_zsk_termine'));
        $mform->addElement('date_time_selector', 'timeend', get_string('event_timeend', 'local_zsk_termine'));
        $mform->hideIf('timeend', 'hasend', 'notchecked');

        $mform->addElement('text', 'location', get_string('event_location', 'local_zsk_termine'), ['size' => 64]);
        $mform->setType('location', PARAM_TEXT);

        $mform->addElement('editor', 'description', get_string('event_description', 'local_zsk_termine'), null, [
            'maxfiles' => 0,
        ]);
        $mform->setType('description', PARAM_RAW);

        $mform->addElement('advcheckbox', 'cancelled', get_string('event_cancelled_field', 'local_zsk_termine'));

        if ($canhighlight) {
            $mform->addElement('advcheckbox', 'highlighted', get_string('event_highlighted', 'local_zsk_termine'));
            $mform->addHelpButton('highlighted', 'event_highlighted', 'local_zsk_termine');
        }

        if ($isnew && $notifyenabled) {
            $mform->addElement('header', 'notificationhdr', get_string('notification_header', 'local_zsk_termine'));

            $mform->addElement('advcheckbox', 'sendnotification', get_string('notification_send', 'local_zsk_termine'));
            $mform->addHelpButton('sendnotification', 'notification_send', 'local_zsk_termine');

            if ($cannotifyall) {
                $audienceoptions = [
                    \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ALL =>
                        get_string('notification_audience_all', 'local_zsk_termine'),
                    \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ENROLLED =>
                        get_string('notification_audience_enrolled', 'local_zsk_termine'),
                ];
            } else {
                $audienceoptions = [
                    \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ENROLLED =>
                        get_string('notification_audience_enrolled', 'local_zsk_termine'),
                ];
                $mform->addElement('static', 'notifyfreelimit', '', get_string('notification_free_limit', 'local_zsk_termine'));
            }

            $mform->addElement('select', 'notifyaudience', get_string('notification_audience', 'local_zsk_termine'), $audienceoptions);
            $mform->addHelpButton('notifyaudience', 'notification_audience', 'local_zsk_termine');
            $mform->hideIf('notifyaudience', 'sendnotification', 'notchecked');
            $mform->hideIf('notifyaudience', 'courseid', 'eq', 0);
            $mform->hideIf('notifyfreelimit', 'sendnotification', 'notchecked');
            $mform->hideIf('notifyfreelimit', 'courseid', 'eq', 0);
        } else if ($isnew && !$notifyenabled) {
            $mform->addElement('static', 'notifydisabled', '', get_string('notification_free_site_disabled', 'local_zsk_termine'));
        }

        $this->add_action_buttons(true, get_string('savechanges'));
    }

    /**
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        if (!empty($data['sendnotification']) && !empty($data['cancelled'])) {
            $errors['sendnotification'] = get_string('notification_cancelled_conflict', 'local_zsk_termine');
        }

        if (!empty($data['sendnotification']) && empty($data['courseid'])
            && !\local_zsk_termine\util\license::can_notify_all_users()) {
            $errors['sendnotification'] = get_string('notification_free_site_disabled', 'local_zsk_termine');
        }

        return $errors;
    }

    public function get_data() {
        $data = parent::get_data();
        if (!$data) {
            return false;
        }
        if (empty($data->hasend)) {
            $data->timeend = 0;
        }
        return $data;
    }
}
