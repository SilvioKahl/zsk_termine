<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\admin;

use local_zsk_termine\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * License key setting that verifies against the external API on save.
 */
class setting_license_key extends \admin_setting_configpasswordunmask {

    public function __construct() {
        parent::__construct(
            'local_zsk_termine/license_key',
            get_string('license_key', 'local_zsk_termine'),
            get_string('license_key_desc', 'local_zsk_termine'),
            ''
        );
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function write_setting($data) {
        $result = parent::write_setting($data);
        if ($result !== '') {
            return $result;
        }

        if ($data === '') {
            license::clear_license();
            return '';
        }

        return self::verify_or_error();
    }

    /**
     * @return string
     */
    public static function verify_or_error(): string {
        $verify = license::verify();
        if ($verify->success) {
            return '';
        }

        if (!empty($verify->network_error) && license::is_premium()) {
            return '';
        }

        return $verify->message !== ''
            ? $verify->message
            : get_string('license_error_network', 'local_zsk_termine');
    }
}
