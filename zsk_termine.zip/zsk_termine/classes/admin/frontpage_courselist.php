<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\admin;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/adminlib.php');

/**
 * Extends the front page element dropdown with upcoming events (and course tiles if present).
 */
class frontpage_courselist extends \admin_setting_courselist_frontpage {

    /**
     * @return bool
     */
    public function load_choices() {
        if (is_array($this->choices)) {
            return true;
        }

        parent::load_choices();

        if (class_exists('\local_tiles2\frontpage')) {
            $this->choices[\local_tiles2\frontpage::FRONTPAGECOURSETILES] = get_string(
                'frontpagecoursetiles',
                'local_tiles2'
            );
        }

        $this->choices[\local_zsk_termine\frontpage::FRONTPAGETERMINE] = get_string(
            'frontpagetermine',
            'local_zsk_termine'
        );

        return true;
    }
}
