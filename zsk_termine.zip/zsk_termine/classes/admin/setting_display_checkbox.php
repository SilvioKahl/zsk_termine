<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\admin;

use local_zsk_termine\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * Display-position checkbox with free-tier limit (one position only).
 */
class setting_display_checkbox extends \admin_setting_configcheckbox {

    /** @var string dashboard|frontpage */
    private string $context;

    /**
     * @param string $context
     * @param string $configname
     * @param string $name
     * @param string $description
     * @param int $default
     */
    public function __construct(string $context, string $configname, string $name, string $description, int $default = 0) {
        $this->context = $context;
        parent::__construct('local_zsk_termine/' . $configname, $name, $description, $default);
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function write_setting($data) {
        if (!empty($data) && !license::can_use_multiple_display_positions()) {
            $otherkey = $this->context === 'dashboard' ? 'block_frontpage' : 'block_dashboard';
            if ((int) get_config('local_zsk_termine', $otherkey)) {
                return get_string('license_error_display_limit', 'local_zsk_termine');
            }
        }

        return parent::write_setting($data);
    }
}
