<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\admin;

use local_zsk_termine\util\license;

defined('MOODLE_INTERNAL') || die();

/**
 * Config text stored under local_zsk_plugins (shared across ZSK plugins).
 */
class setting_shared_configtext extends \admin_setting_configtext {

    /** @var bool */
    private $reverifyonchange;

    /**
     * @param string $name Config name without plugin prefix.
     * @param string $visiblename
     * @param string $description
     * @param string $default
     * @param mixed $paramtype Moodle PARAM_* constant.
     * @param bool $reverifyonchange Re-run termine license verify when changed.
     */
    public function __construct(
        $name,
        $visiblename,
        $description,
        $default,
        $paramtype = PARAM_TEXT,
        $reverifyonchange = false
    ) {
        $this->reverifyonchange = (bool) $reverifyonchange;
        parent::__construct('local_zsk_plugins/' . $name, $visiblename, $description, $default, $paramtype);
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function write_setting($data) {
        $result = parent::write_setting($data);
        if ($result !== '' || !$this->reverifyonchange) {
            return $result;
        }

        if (!empty(get_config('local_zsk_termine', 'license_key'))) {
            $error = setting_license_key::verify_or_error();
            if ($error !== '') {
                return $error;
            }
        }

        return '';
    }
}
