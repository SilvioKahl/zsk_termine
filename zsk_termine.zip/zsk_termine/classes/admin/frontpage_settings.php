<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine\admin;

defined('MOODLE_INTERNAL') || die();

/**
 * Replace core frontpage list settings with versions that include upcoming events.
 */
class frontpage_settings {

    /**
     * @return void
     */
    public static function patch_admin_tree(): void {
        global $ADMIN;

        if (during_initial_install() || !isset($ADMIN)) {
            return;
        }

        self::replace_setting_on_page($ADMIN, 'frontpagesettings', 'frontpageloggedin', true);
        self::replace_setting_on_page($ADMIN, 'frontpagesettings', 'frontpage', false);
    }

    /**
     * @param \admin_root $admin
     * @param string $pageid
     * @param string $settingname
     * @param bool $loggedin
     */
    protected static function replace_setting_on_page(
        \admin_root $admin,
        string $pageid,
        string $settingname,
        bool $loggedin
    ): void {
        $page = $admin->locate($pageid, false);
        if (!$page || !($page instanceof \admin_settingpage)) {
            return;
        }

        if (empty($page->settings)) {
            return;
        }

        foreach ($page->settings as $key => $setting) {
            if (!($setting instanceof \admin_setting_courselist_frontpage)) {
                continue;
            }
            if ($setting instanceof frontpage_courselist) {
                return;
            }
            if ($setting->name !== $settingname) {
                continue;
            }

            if (is_object($page->settings)) {
                $page->settings->{$key} = new frontpage_courselist($loggedin);
            } else {
                $page->settings[$key] = new frontpage_courselist($loggedin);
            }
            return;
        }
    }
}
