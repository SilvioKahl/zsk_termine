<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine;

defined('MOODLE_INTERNAL') || die();

/**
 * Legacy block_upcomingevents cleanup (dashboard now uses output hooks).
 */
class dashboard_block {

    /**
     * @deprecated Dashboard display uses output hooks; block_upcomingevents is no longer required.
     * Kept as no-op so legacy block plugin install/upgrade does not fatal.
     *
     * @return void
     */
    public static function ensure_default_instance(): void {
        // Intentionally empty – see hook_callbacks::inject_dashboard_termine().
    }

    /**
     * Remove block_upcomingevents instances created by older plugin versions.
     *
     * @return int Number of removed instances.
     */
    public static function remove_legacy_block_instances(): int {
        global $DB, $CFG;

        require_once($CFG->libdir . '/blocklib.php');

        $instances = $DB->get_records('block_instances', ['blockname' => 'upcomingevents']);
        $removed = 0;
        foreach ($instances as $instance) {
            blocks_delete_instance($instance);
            $removed++;
        }

        return $removed;
    }
}
