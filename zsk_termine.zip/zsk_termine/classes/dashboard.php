<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine;

defined('MOODLE_INTERNAL') || die();

/**
 * Dashboard (/my/) centre-column integration via output hooks.
 */
class dashboard {

    /**
     * @return string
     */
    public static function render_termine_section(): string {
        if (!\local_zsk_termine_block_enabled_for('dashboard') || !\local_zsk_termine_user_can_view()) {
            return '';
        }

        $html = \local_zsk_termine_render_upcoming_block_html();
        if ($html === '') {
            return '';
        }

        $header = get_string('upcoming_heading', 'local_zsk_termine');
        $section = \html_writer::link(
            '#skipdashboardtermine',
            get_string('skipa', 'access', \core_text::strtolower(strip_tags($header))),
            ['class' => 'skip-block skip aabtn']
        );
        $section .= \html_writer::start_tag('div', [
            'id' => 'dashboard-upcoming-events',
            'class' => 'local-termine-dashboard-section',
        ]);
        $section .= $html;
        $section .= \html_writer::end_tag('div');
        $section .= \html_writer::tag('span', '', ['class' => 'skip-block-to', 'id' => 'skipdashboardtermine']);

        return $section;
    }
}
