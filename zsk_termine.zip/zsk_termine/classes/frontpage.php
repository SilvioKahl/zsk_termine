<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_termine;

defined('MOODLE_INTERNAL') || die();

/**
 * Front page centre-column integration (Startseite nach Anmeldung).
 */
class frontpage {

    /** @var string Custom frontpage slot value (not used by Moodle core). */
    public const FRONTPAGETERMINE = '9';

    /**
     * @param bool $loggedin
     * @return string[]
     */
    public static function get_layout_slots(bool $loggedin = true): array {
        global $CFG;

        $key = $loggedin ? 'frontpageloggedin' : 'frontpage';
        $layout = isset($CFG->$key) ? (string) $CFG->$key : '';
        if ($layout === '') {
            return [];
        }

        $slots = [];
        foreach (explode(',', $layout) as $slot) {
            $slot = trim($slot);
            if ($slot !== '' && $slot !== 'none') {
                $slots[] = $slot;
            }
        }

        return $slots;
    }

    /**
     * @param bool $loggedin
     * @return bool
     */
    public static function layout_includes_termine(bool $loggedin = true): bool {
        return in_array(self::FRONTPAGETERMINE, self::get_layout_slots($loggedin), true);
    }

    /**
     * @return int|false Zero-based position among centre-column frontpage elements.
     */
    public static function get_termine_slot_index(): int|false {
        $slots = self::get_layout_slots(true);
        $index = array_search(self::FRONTPAGETERMINE, $slots, true);
        return $index === false ? false : (int) $index;
    }

    /**
     * @return string
     */
    public static function render_termine_section(): string {
        if (!\local_zsk_termine_block_enabled_for('frontpage') || !\local_zsk_termine_user_can_view()) {
            return '';
        }

        $html = \local_zsk_termine_render_upcoming_block_html();
        if ($html === '') {
            return '';
        }

        $header = get_string('frontpagetermine_heading', 'local_zsk_termine');
        $section = \html_writer::link(
            '#skiptermine',
            get_string('skipa', 'access', \core_text::strtolower(strip_tags($header))),
            ['class' => 'skip-block skip aabtn']
        );
        $section .= \html_writer::start_tag('div', [
            'id' => 'frontpage-upcoming-events',
            'class' => 'local-termine-frontpage-section',
        ]);
        $section .= $html;
        $section .= \html_writer::end_tag('div');
        $section .= \html_writer::tag('span', '', ['class' => 'skip-block-to', 'id' => 'skiptermine']);

        return $section;
    }
}
