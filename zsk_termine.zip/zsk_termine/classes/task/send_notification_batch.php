<?php

// This file is part of Moodle - http://moodle.org/



namespace local_zsk_termine\task;



defined('MOODLE_INTERNAL') || die();



/**

 * Adhoc task: send event notification emails to a batch of users.

 */

class send_notification_batch extends \core\task\adhoc_task {



    /**

     * @return string

     */

    public function get_name(): string {

        return get_string('task_send_notification_batch', 'local_zsk_termine');

    }



    /**

     * @return void

     */

    public function execute(): void {

        global $CFG;



        require_once($CFG->dirroot . '/local/zsk_termine/lib.php');



        $data = $this->get_custom_data();

        if (empty($data) || empty($data->userids) || !is_array($data->userids)) {

            mtrace('local_zsk_termine send_notification_batch: no recipients, skipping.');

            return;

        }



        $eventid = (int) ($data->eventid ?? 0);

        $sendtype = (string) ($data->sendtype ?? \local_zsk_termine\notification\template_resolver::SENDTYPE_NEW);

        $event = $eventid > 0 ? local_zsk_termine_get_event($eventid) : null;



        $sent = 0;

        $skipped = 0;

        $failed = 0;



        foreach ($data->userids as $userid) {

            $userid = (int) $userid;

            if ($userid <= 1) {

                $skipped++;

                continue;

            }



            $user = \core_user::get_user($userid, '*', IGNORE_MISSING);

            if (!$user || !empty($user->deleted) || empty($user->email)) {

                mtrace("local_zsk_termine send_notification_batch: skip user {$userid}.");

                $skipped++;

                continue;

            }



            if ($event) {

                [$subject, $bodyhtml, $bodyplain] = \local_zsk_termine\notification\mailer::build_message($event, $user, $sendtype);

            } else {

                $subject = trim((string) ($data->subject ?? ''));

                $bodyhtml = (string) ($data->bodyhtml ?? '');

                $bodyplain = (string) ($data->bodyplain ?? '');

            }



            if ($subject === '') {

                $skipped++;

                continue;

            }



            try {

                $ok = \local_zsk_termine\notification\mailer::send_to_user($user, $subject, $bodyhtml, $bodyplain);

                if ($ok) {

                    $sent++;

                } else {

                    $failed++;

                }

            } catch (\Throwable $e) {

                $failed++;

                mtrace('local_zsk_termine send_notification_batch: exception for user ' . $userid . ': ' . $e->getMessage());

            }

        }



        mtrace("local_zsk_termine send_notification_batch: sent={$sent}, skipped={$skipped}, failed={$failed}.");

    }

}

