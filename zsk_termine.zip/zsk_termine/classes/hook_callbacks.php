<?php

// This file is part of Moodle - http://moodle.org/



namespace local_zsk_termine;



defined('MOODLE_INTERNAL') || die();



require_once(__DIR__ . '/../lib.php');



class hook_callbacks {

    /**
     * Pages that show the upcoming-events block via dashboard settings.
     *
     * @param string $pagetype
     * @return bool
     */
    protected static function is_dashboard_termine_page(string $pagetype): bool {
        return in_array($pagetype, ['my-index', 'my-courses'], true);
    }

    /**

     * @param \core\hook\navigation\primary_extend $hook

     */

    public static function extend_primary_navigation(\core\hook\navigation\primary_extend $hook): void {

        if (!\local_zsk_termine_should_show_navigation()) {

            return;

        }



        $primaryview = $hook->get_primaryview();

        if ($primaryview->find('local_zsk_termine', \navigation_node::TYPE_CUSTOM)) {

            return;

        }



        $primaryview->add(

            get_string('pluginname', 'local_zsk_termine'),

            new \moodle_url('/local/zsk_termine/manage.php'),

            \navigation_node::TYPE_CUSTOM,

            null,

            'local_zsk_termine',

            \local_zsk_termine_get_navigation_pix_icon()

        );

    }



    /**

     * Register termine CSS in <head> before it is printed (site home).

     *

     * @param \core\hook\output\before_standard_head_html_generation $hook

     */

    public static function register_page_styles(

        \core\hook\output\before_standard_head_html_generation $hook

    ): void {

        global $PAGE;

        $needsstyles = false;

        if ($PAGE->pagetype === 'site-index'
            && frontpage::layout_includes_termine(true)
            && \local_zsk_termine_block_enabled_for('frontpage')) {
            $needsstyles = true;
        }

        if (self::is_dashboard_termine_page($PAGE->pagetype)
            && \local_zsk_termine_block_enabled_for('dashboard')) {
            $needsstyles = true;
        }

        if (!$needsstyles) {
            return;
        }

        $late = \local_zsk_termine_require_styles();

        if ($late !== '') {

            $hook->add_html($late);

        }

    }



    /**

     * @param \core\hook\output\before_footer_html_generation $hook

     */

    public static function inject_upcoming_block(\core\hook\output\before_footer_html_generation $hook): void {

        self::inject_frontpage_termine($hook);
        self::inject_dashboard_termine($hook);

    }



    /**

     * Render upcoming events in the front page centre column (Startseite nach Anmeldung).

     *

     * @param \core\hook\output\before_footer_html_generation $hook

     */

    public static function inject_frontpage_termine(

        \core\hook\output\before_footer_html_generation $hook

    ): void {

        global $PAGE;



        if ($PAGE->pagetype !== 'site-index' || !frontpage::layout_includes_termine(true)) {

            return;

        }



        if (!\local_zsk_termine_block_enabled_for('frontpage')) {

            return;

        }



        $slotindex = frontpage::get_termine_slot_index();

        if ($slotindex === false) {

            return;

        }



        $html = frontpage::render_termine_section();

        if ($html === '') {

            return;

        }



        $html = \html_writer::div(

            $html,

            'local-termine-frontpage-pending',

            [

                'id' => 'local-termine-frontpage-pending',

                'data-slot-index' => (string) $slotindex,

            ]

        );



        $hook->add_html(\local_zsk_termine_require_styles() . $html);

        $PAGE->requires->js_init_code(self::frontpage_position_script());

    }

    /**
     * Render upcoming events in the dashboard centre column (/my/).
     *
     * @param \core\hook\output\before_footer_html_generation $hook
     */
    public static function inject_dashboard_termine(
        \core\hook\output\before_footer_html_generation $hook
    ): void {
        global $PAGE;

        if (!self::is_dashboard_termine_page($PAGE->pagetype)) {
            return;
        }

        if (!\local_zsk_termine_block_enabled_for('dashboard')) {
            return;
        }

        $html = dashboard::render_termine_section();
        if ($html === '') {
            return;
        }

        $html = \html_writer::div(
            $html,
            'local-termine-dashboard-pending',
            [
                'id' => 'local-termine-dashboard-pending',
            ]
        );

        $hook->add_html(\local_zsk_termine_require_styles() . $html);
        $PAGE->requires->js_init_code(self::dashboard_position_script());
    }

    /**

     * @return string

     */

    protected static function frontpage_position_script(): string {

        return <<<'JS'

(function() {

    function placeFrontpageTermine() {

        var pending = document.getElementById('local-termine-frontpage-pending');

        if (!pending) {

            return;

        }

        var section = document.getElementById('frontpage-upcoming-events');

        if (!section || section.closest('#local-termine-frontpage-pending')) {

            section = pending.querySelector('#frontpage-upcoming-events');

        }

        if (!section) {

            return;

        }

        var main = document.querySelector('#region-main');

        if (!main) {

            return;

        }

        var slot = parseInt(pending.getAttribute('data-slot-index') || '0', 10);

        var selector = '#site-news-forum, #frontpage-course-list, #frontpage-available-course-list, ' +

            '#frontpage-category-names, #frontpage-category-combo, #frontpage-course-tiles, ' +

            '#frontpage-upcoming-events';

        var existing = [];

        main.querySelectorAll(selector).forEach(function(el) {

            if (!el.closest('#local-termine-frontpage-pending')) {

                existing.push(el);

            }

        });

        pending.removeAttribute('id');

        pending.classList.remove('local-termine-frontpage-pending');

        var ref = existing[slot] || null;

        if (ref) {

            main.insertBefore(pending, ref);

        } else if (slot === 0) {

            main.insertBefore(pending, main.firstChild);

        } else {

            main.appendChild(pending);

        }

    }

    if (document.readyState === 'loading') {

        document.addEventListener('DOMContentLoaded', placeFrontpageTermine);

    } else {

        placeFrontpageTermine();

    }

})();

JS;

    }

    /**
     * @return string
     */
    protected static function dashboard_position_script(): string {
        return <<<'JS'
(function() {
    function placeDashboardTermine() {
        var pending = document.getElementById('local-termine-dashboard-pending');
        if (!pending) {
            return;
        }

        var section = document.getElementById('dashboard-upcoming-events');
        if (!section || section.closest('#local-termine-dashboard-pending')) {
            section = pending.querySelector('#dashboard-upcoming-events');
        }
        if (!section) {
            return;
        }

        var main = document.querySelector('#region-main');
        if (!main) {
            return;
        }

        pending.removeAttribute('id');
        pending.classList.remove('local-termine-dashboard-pending');
        main.insertBefore(pending, main.firstChild);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', placeDashboardTermine);
    } else {
        placeDashboardTermine();
    }
})();
JS;
    }

}

