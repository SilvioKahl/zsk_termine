<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/lib.php');

use local_zsk_termine\util\license;

if ($hassiteconfig) {
    $appearanceparent = 'themes';

    $blocksettings = new admin_settingpage(
        'local_zsk_termine_block',
        get_string('blocksettings_heading', 'local_zsk_termine')
    );

    $blocksettings->add(new admin_setting_heading(
        'local_zsk_termine/block_intro',
        get_string('blocksettings_heading', 'local_zsk_termine'),
        get_string('blocksettings_intro', 'local_zsk_termine')
    ));

    $blocksettings->add(new admin_setting_description(
        'local_zsk_termine/block_license_status',
        get_string('license_status', 'local_zsk_termine'),
        license::get_status_string()
    ));

    $blocksettings->add(new \local_zsk_termine\admin\setting_display_checkbox(
        'frontpage',
        'block_frontpage',
        get_string('block_frontpage', 'local_zsk_termine'),
        get_string('block_frontpage_desc', 'local_zsk_termine') . ' ' .
            get_string('license_display_free_hint', 'local_zsk_termine'),
        0
    ));

    $blocksettings->add(new \local_zsk_termine\admin\setting_display_checkbox(
        'dashboard',
        'block_dashboard',
        get_string('block_dashboard', 'local_zsk_termine'),
        get_string('block_dashboard_desc', 'local_zsk_termine') . ' ' .
            get_string('license_display_free_hint', 'local_zsk_termine'),
        0
    ));

    $blocksettings->add(new admin_setting_description(
        'local_zsk_termine/block_frontpage_slot',
        get_string('block_frontpage_slot', 'local_zsk_termine'),
        get_string('block_frontpage_slot_desc', 'local_zsk_termine')
    ));

    $blocksettings->add(new admin_setting_configselect(
        'local_zsk_termine/block_preview_count',
        get_string('block_preview_count', 'local_zsk_termine'),
        get_string('block_preview_count_desc', 'local_zsk_termine'),
        3,
        license::get_preview_count_options()
    ));

    $ADMIN->add($appearanceparent, $blocksettings);

    require_once(__DIR__ . '/classes/admin/frontpage_settings.php');
    \local_zsk_termine\admin\frontpage_settings::patch_admin_tree();

    if (!$ADMIN->locate('zskplugins')) {
        $ADMIN->add('localplugins', new admin_category(
            'zskplugins',
            get_string('admin_category_zsk_plugins', 'local_zsk_termine')
        ));
    }

    license::refresh_status_if_key_present();

    // Primary plugin settings section (linked as "Einstellungen" from the plugin list).
    $licenses = new admin_settingpage(
        'local_zsk_termine',
        get_string('license_hub_title', 'local_zsk_termine')
    );

    $licenses->add(new admin_setting_heading(
        'local_zsk_plugins/shared_heading',
        get_string('license_hub_shared_heading', 'local_zsk_termine'),
        get_string('license_hub_shared_desc', 'local_zsk_termine')
    ));

    $licenses->add(new \local_zsk_termine\admin\setting_shared_configtext(
        'license_server_url',
        get_string('license_server_url', 'local_zsk_termine'),
        get_string('license_server_url_desc', 'local_zsk_termine'),
        '',
        PARAM_RAW,
        true
    ));

    $licenses->add(new \local_zsk_termine\admin\setting_shared_configtext(
        'license_grace_days',
        get_string('license_grace_days', 'local_zsk_termine'),
        get_string('license_grace_days_desc', 'local_zsk_termine'),
        '7',
        PARAM_INT,
        false
    ));

    $licenses->add(new admin_setting_heading(
        'local_zsk_termine/license_termine_heading',
        get_string('license_hub_termine_heading', 'local_zsk_termine'),
        get_string('license_key_desc', 'local_zsk_termine')
    ));

    $licenses->add(new \local_zsk_termine\admin\setting_license_key());

    $licenses->add(new admin_setting_description(
        'local_zsk_termine/license_status',
        get_string('license_status', 'local_zsk_termine'),
        license::get_status_string()
    ));

    $licenses->add(new admin_setting_description(
        'local_zsk_termine/license_hub_other',
        get_string('license_hub_other_heading', 'local_zsk_termine'),
        get_string('license_hub_other_desc', 'local_zsk_termine')
    ));

    $terminesettings = new admin_settingpage(
        'local_zsk_termine_config',
        get_string('termine_settings', 'local_zsk_termine')
    );

    $terminesettings->add(new admin_setting_configselect(
        'local_zsk_termine/accessmode',
        get_string('accessmode', 'local_zsk_termine'),
        get_string('accessmode_desc', 'local_zsk_termine'),
        0,
        [
            0 => get_string('accessmode_allowlist', 'local_zsk_termine'),
            1 => get_string('accessmode_capability', 'local_zsk_termine'),
        ]
    ));

    $terminesettings->add(new admin_setting_heading(
        'local_zsk_termine/notify_heading',
        get_string('notification_settings_heading', 'local_zsk_termine'),
        get_string('notification_settings_desc', 'local_zsk_termine')
    ));

    $terminesettings->add(new admin_setting_configcheckbox(
        'local_zsk_termine/notify_enabled',
        get_string('notification_settings_enabled', 'local_zsk_termine'),
        get_string('notification_settings_enabled_desc', 'local_zsk_termine'),
        1
    ));

    $terminesettings->add(new admin_setting_configtext(
        'local_zsk_termine/notify_batchsize',
        get_string('notification_settings_batchsize', 'local_zsk_termine'),
        get_string('notification_settings_batchsize_desc', 'local_zsk_termine'),
        50,
        PARAM_INT
    ));

    $terminesettings->add(new admin_setting_heading(
        'local_zsk_termine/pro_heading',
        get_string('pro_settings_heading', 'local_zsk_termine'),
        license::is_premium()
            ? get_string('pro_settings_desc', 'local_zsk_termine')
            : get_string('pro_settings_locked', 'local_zsk_termine')
    ));

    $terminesettings->add(new admin_setting_configtext(
        'local_zsk_termine/reminder_days_before',
        get_string('reminder_days_before', 'local_zsk_termine'),
        get_string('reminder_days_before_desc', 'local_zsk_termine'),
        1,
        PARAM_INT
    ));

    $terminesettings->add(new admin_setting_configtext(
        'local_zsk_termine/webhook_url',
        get_string('webhook_url', 'local_zsk_termine'),
        get_string('webhook_url_desc', 'local_zsk_termine'),
        '',
        PARAM_URL
    ));

    $terminesettings->add(new admin_setting_configpasswordunmask(
        'local_zsk_termine/webhook_secret',
        get_string('webhook_secret', 'local_zsk_termine'),
        get_string('webhook_secret_desc', 'local_zsk_termine'),
        ''
    ));

    if (license::can_use_webhook()) {
        local_zsk_termine_ensure_ical_feed_token();
        $icalurl = (new moodle_url('/local/zsk_termine/ical.php', [
            'token' => get_config('local_zsk_termine', 'ical_feed_token'),
        ]))->out(false);
        $terminesettings->add(new admin_setting_description(
            'local_zsk_termine/ical_feed_url',
            get_string('ical_feed_url', 'local_zsk_termine'),
            html_writer::tag('code', s($icalurl))
        ));
    }

    $ADMIN->add('zskplugins', $licenses);
    $ADMIN->add('zskplugins', $terminesettings);
    $ADMIN->add('zskplugins', new admin_externalpage(
        'local_zsk_termine_manageaccess',
        get_string('manageaccess', 'local_zsk_termine'),
        new moodle_url('/local/zsk_termine/manageaccess.php'),
        'moodle/site:config'
    ));
}
