<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'ZSK Nächste Termine';
$string['privacy:metadata'] = 'Das Plugin „Nächste Termine“ speichert Termine und Berechtigungen.';

$string['nopermission'] = 'Sie haben keine Berechtigung für diese Aktion.';

$string['upcoming_heading'] = 'Nächste Termine';
$string['more_events'] = 'Weitere Termine …';
$string['all_events'] = 'Alle Termine';
$string['all_categories'] = 'Alle Kategorien';
$string['no_events'] = 'Derzeit sind keine kommenden Termine eingetragen.';
$string['event_cancelled'] = 'Abgesagt';

$string['manage_events'] = 'Termine verwalten';
$string['manage_events_list'] = 'Terminliste (Pflege)';
$string['manage_categories'] = 'Kategorien verwalten';
$string['manageaccess'] = 'Berechtigungen ZSK Termine';
$string['manageaccess_desc'] = 'Legen Sie fest, welche Benutzer Termine anlegen, bearbeiten, absagen und löschen dürfen. Site-Administratoren haben immer Zugriff.';
$string['manageaccess_saved'] = 'Berechtigungen gespeichert.';
$string['manageaccess_tables_missing'] = 'Die Berechtigungstabellen fehlen. Bitte führen Sie das Plugin-Upgrade aus.';
$string['allowmanageusers'] = 'Berechtigte Benutzer';
$string['allowmanageusers_help'] = 'Diese Benutzer dürfen Termine und Kategorien pflegen (zusätzlich zu Nutzern mit der Systemberechtigung „Termine verwalten“).';

$string['add_event'] = 'Termin anlegen';
$string['edit_event'] = 'Termin bearbeiten';
$string['delete_event'] = 'Termin löschen';
$string['delete_event_confirm'] = 'Termin „{$a}“ wirklich löschen?';
$string['event_saved'] = 'Termin gespeichert.';
$string['event_deleted'] = 'Termin gelöscht.';
$string['event_cancel_action'] = 'Absagen';
$string['event_cancelled_done'] = 'Termin wurde als abgesagt markiert.';

$string['event_title'] = 'Titel';
$string['event_category'] = 'Kategorie';
$string['event_course'] = 'Kurszuordnung';
$string['event_course_none'] = 'Kein Kurs (übergreifend)';
$string['event_course_help'] = 'Optional einem Kurs zuordnen. Auf Startseite, Dashboard und „Meine Kurse“ erscheinen alle kommenden Termine; in der Kursaktivität nur die des jeweiligen Kurses.';
$string['event_timestart'] = 'Beginn';
$string['event_timeend'] = 'Ende';
$string['event_hasend'] = 'Endzeit angeben';
$string['event_location'] = 'Ort';
$string['event_description'] = 'Beschreibung';
$string['event_cancelled_field'] = 'Termin ist abgesagt';
$string['event_highlighted'] = 'Termin farblich hervorheben';
$string['event_highlighted_help'] = 'Der Termin wird in Listen und im Block mit farbiger Unterlegung angezeigt (z. B. für besonders wichtige Termine).';
$string['invalidevent'] = 'Unbekannter Termin.';
$string['no_categories'] = 'Bitte legen Sie zuerst mindestens eine Kategorie an.';

$string['category_name'] = 'Name der Kategorie';
$string['category_icon'] = 'Icon';
$string['category_icon_help'] = 'Moodle-Pix-Icon, z. B. i/calendar, i/cohort, i/group. Siehe Theme-Iconset.';
$string['category_sortorder'] = 'Reihenfolge';
$string['category_saved'] = 'Kategorie gespeichert.';
$string['category_deleted'] = 'Kategorie gelöscht.';
$string['category_delete_confirm'] = 'Kategorie wirklich löschen?';
$string['category_delete_blocked'] = 'Kategorie kann nicht gelöscht werden, solange Termine zugeordnet sind.';
$string['add_category'] = 'Kategorie anlegen';

$string['actions'] = 'Aktionen';
$string['settings'] = 'Einstellungen';
$string['termine_settings'] = 'ZSK Termine – Einstellungen';
$string['admin_category_zsk_plugins'] = 'ZSK-Plugins';
$string['license_hub_title'] = 'Lizenzen ZSK-Plugins';
$string['license_hub_shared_heading'] = 'Gemeinsame Lizenzserver-Einstellungen';
$string['license_hub_shared_desc'] = 'URL und Offline-Toleranz gelten für alle ZSK-Plugins auf dieser Moodle-Instanz.';
$string['license_hub_termine_heading'] = 'ZSK Termine';
$string['license_hub_other_heading'] = 'Weitere ZSK-Plugins';
$string['license_hub_other_desc'] = 'Lizenzen für weitere ZSK-Plugins (z. B. Course Content Health Dashboard) werden hier ergänzt, sobald die Plugins an diese zentrale Seite angebunden sind.';

$string['blocksettings_heading'] = 'Startseite & Dashboard';
$string['blocksettings_intro'] = 'Startseite: Element in den Startseiten-Einstellungen wählen. Dashboard: Anzeige in der Mitte von /my/ (ohne separaten Block).';
$string['block_dashboard'] = 'Nächste Termine auf dem Dashboard (Mitte) erlauben';
$string['block_dashboard_desc'] = 'Zeigt kommende Termine oben in der Mitte des Dashboards (/my/). Kein zusätzliches Block-Plugin erforderlich.';
$string['block_frontpage'] = 'Nächste Termine auf der Startseite (Mitte) erlauben';
$string['block_frontpage_desc'] = 'Wenn in den Startseiten-Einstellungen „Nächste Termine“ gewählt ist, werden kommende Termine in der Mitte angezeigt.';
$string['block_frontpage_slot'] = 'Reihenfolge auf der Startseite';
$string['block_frontpage_slot_desc'] = 'Website-Administration → Startseite → Startseite-Einstellungen → „Startseite nach Anmeldung“: Element „Nächste Termine“ wählen und per Reihenfolge gegenüber Kurs-Kacheln, Kursliste usw. positionieren.';
$string['frontpagetermine'] = 'Nächste Termine';
$string['frontpagetermine_heading'] = 'Nächste Termine';
$string['block_preview_count'] = 'Anzahl Termine in der Kurzansicht';
$string['block_preview_count_desc'] = '3 oder 4 Termine im Block; bei weiteren erscheint der Link „Weitere Termine …”.';
$string['block_position'] = 'Position zum Kachelblock';
$string['block_position_desc'] = 'Nur relevant, wenn die Kachelansicht (local_tiles) auf derselben Seite aktiv ist.';
$string['block_position_before'] = 'Vor den Kacheln';
$string['block_position_after'] = 'Nach den Kacheln';
$string['blocksettings_admin_hint'] = 'Einstellungen unter Website-Administration → Darstellung → Startseite & Dashboard.';

$string['accessmode'] = 'Zugriff auf Verwaltung';
$string['accessmode_desc'] = 'Zusätzlich zur Benutzerliste können Sie die Berechtigung „Termine verwalten“ vergeben.';
$string['accessmode_allowlist'] = 'Benutzerliste + Administratoren';
$string['accessmode_capability'] = 'Nur Berechtigung „Termine verwalten“ (und Administratoren)';

$string['notification_header'] = 'E-Mail-Benachrichtigung';
$string['notification_send'] = 'E-Mail-Benachrichtigung beim Speichern versenden';
$string['notification_send_help'] = 'Nur beim Anlegen eines neuen Termins. Der Versand erfolgt asynchron über die Moodle-Aufgaben-Warteschlange (Cron). Abgesagte Termine werden nicht per E-Mail angekündigt.';
$string['notification_audience'] = 'Empfänger';
$string['notification_audience_help'] = 'Bei Terminen ohne Kurszuordnung werden immer alle aktiven Benutzer mit gültiger E-Mail-Adresse benachrichtigt. Bei Kursterminen können Sie wahlweise alle Benutzer oder nur die im Kurs eingeschriebenen Benutzer wählen.';
$string['notification_audience_all'] = 'Alle Benutzer des Systems';
$string['notification_audience_enrolled'] = 'Nur im Kurs eingeschriebene Benutzer';
$string['notification_cancelled_conflict'] = 'Ein abgesagter Termin kann nicht per E-Mail angekündigt werden.';
$string['event_saved_notify_queued'] = 'Termin gespeichert. E-Mail-Benachrichtigung an {$a} Empfänger wurde in die Warteschlange gestellt.';
$string['notification_subject'] = 'Neuer Termin: {$a}';
$string['notification_intro'] = 'Es wurde ein neuer Termin eingetragen:';
$string['notification_when'] = 'Zeit: {$a}';
$string['notification_category'] = 'Kategorie: {$a}';
$string['notification_location'] = 'Ort: {$a}';
$string['notification_course'] = 'Kurs: {$a}';
$string['notification_viewlink'] = 'Termin ansehen';
$string['notification_sender_fallback'] = 'Lernplattform Moodle';
$string['notification_settings_heading'] = 'E-Mail-Benachrichtigungen';
$string['notification_settings_desc'] = 'Optionale E-Mail-Ankündigung beim Anlegen neuer Termine (nur neue Termine, nicht beim Bearbeiten).';
$string['notification_settings_enabled'] = 'E-Mail-Benachrichtigungen erlauben';
$string['notification_settings_enabled_desc'] = 'Zeigt beim Anlegen eines Termins die Option zum Versenden einer E-Mail.';
$string['notification_settings_batchsize'] = 'Batch-Größe für E-Mail-Versand';
$string['notification_settings_batchsize_desc'] = 'Anzahl Empfänger pro Hintergrund-Aufgabe (Standard: 50).';
$string['task_send_notification_batch'] = 'Termine: E-Mail-Batch versenden';

$string['license_heading'] = 'Lizenz (Pro / Premium)';
$string['license_heading_desc'] = 'Lizenzschlüssel für Pro-Funktionen. Ohne gültige Lizenz gilt die kostenlose Version mit den unten beschriebenen Grenzen.';
$string['license_key'] = 'Premium-Lizenzschlüssel';
$string['license_key_desc'] = 'Nur Schlüssel für ZSK Termine (Plugin local_zsk_termine). Auf dem Lizenzserver anlegen mit: php cli/create_license.php --plugin=local_zsk_termine. Schlüssel vom Health Dashboard (ZSK-HD-…) funktionieren hier nicht.';
$string['license_status_key_unverified'] = 'Lizenzschlüssel gespeichert, aber nicht verifiziert – bitte Schlüssel erneut speichern oder Lizenzserver prüfen.';
$string['license_status_key_no_server'] = 'Lizenzschlüssel gespeichert, aber keine Lizenzserver-URL hinterlegt.';
$string['license_server_url'] = 'URL des Lizenzservers';
$string['license_server_url_desc'] = 'Volle URL zum Verify-Endpunkt (z. B. http://ihr-server/zsk-license/api/v1/verify.php). Kein vorgegebener Standardwert.';
$string['license_status'] = 'Lizenzstatus';
$string['license_status_free'] = 'Kostenlose Version (max. 3 Kategorien, 1 Anzeige-Position, max. 3 Termine, max. 2 berechtigte Nutzer, E-Mail nur an Kurseingeschriebene max. 50)';
$string['license_status_premium'] = 'Premium (alle Pro-Funktionen aktiv)';
$string['license_status_premium_slots'] = 'Premium ({$a->used}/{$a->max} Umgebungen gebunden)';
$string['license_status_enterprise'] = 'Enterprise (alle Funktionen inkl. Add-ons)';
$string['license_status_enterprise_slots'] = 'Enterprise ({$a->used}/{$a->max} Umgebungen gebunden)';
$string['license_status_site_limit'] = 'Alle {$a} Umgebungs-Slots belegt – diese Instanz ist nicht lizenziert';
$string['license_status_grace'] = 'Premium (Offline-Toleranz: {$a} Tage, Lizenzserver nicht erreichbar)';
$string['license_status_expired'] = 'Lizenz abgelaufen – Kostenlose Version';
$string['license_status_invalid'] = 'Ungültiger Lizenzschlüssel – Kostenlose Version';
$string['license_status_site_mismatch'] = 'Lizenzschlüssel an andere Moodle-URL gebunden – Kostenlose Version';
$string['license_grace_days'] = 'Offline-Toleranz (Tage)';
$string['license_grace_days_desc'] = 'Bei vorübergehend nicht erreichbarem Lizenzserver bleibt Premium für diese Anzahl Tage aktiv.';
$string['license_error_no_server'] = 'Keine Lizenzserver-URL konfiguriert.';
$string['license_error_network'] = 'Lizenzserver nicht erreichbar und keine gültige Offline-Toleranz vorhanden.';
$string['license_error_expired'] = 'Die Lizenz ist abgelaufen.';
$string['license_error_invalid'] = 'Der Lizenzschlüssel ist ungültig.';
$string['license_error_site_mismatch'] = 'Dieser Lizenzschlüssel ist bereits an eine andere Moodle-Instanz gebunden.';
$string['license_error_site_limit'] = 'Alle {$a} Umgebungs-Slots sind bereits belegt.';
$string['license_error_inactive'] = 'Dieser Lizenzschlüssel wurde deaktiviert.';
$string['license_error_plugin_mismatch'] = 'Dieser Lizenzschlüssel gilt nicht für dieses Plugin.';
$string['license_error_display_limit'] = 'In der kostenlosen Version ist nur eine Anzeige-Position gleichzeitig erlaubt (Startseite oder Dashboard/Meine Kurse).';
$string['license_error_category_limit'] = 'In der kostenlosen Version sind maximal {$a} Kategorien erlaubt.';
$string['license_category_limit_notice'] = 'Kostenlose Version: maximal {$a} Kategorien. Premium hebt dieses Limit auf.';
$string['license_error_allowlist_limit'] = 'In der kostenlosen Version sind maximal {$a} berechtigte Benutzer erlaubt.';
$string['license_allowlist_limit_notice'] = 'Kostenlose Version: maximal {$a} berechtigte Benutzer. Premium hebt dieses Limit auf.';
$string['license_display_free_hint'] = '(Kostenlose Version: nur eine Position gleichzeitig.)';
$string['freemium_branding'] = 'Termine mit ZSK Termine';
$string['notification_free_limit'] = 'Kostenlose Version: E-Mail nur an im Kurs eingeschriebene Benutzer (max. 50 Empfänger).';
$string['notification_free_site_disabled'] = 'E-Mail-Benachrichtigungen für übergreifende Termine sind nur mit Premium verfügbar. Bei Kursterminen: nur eingeschriebene Benutzer (max. 50).';
$string['task_verify_license'] = 'Termine: Lizenz prüfen';
$string['task_send_reminders'] = 'Termine: Erinnerungs-E-Mails versenden';

$string['pro_feature_required'] = 'Diese Funktion ist nur mit Pro/Premium verfügbar.';
$string['pro_settings_heading'] = 'Pro-Funktionen';
$string['pro_settings_desc'] = 'Webhook, iCal-Feed, Erinnerungen, Statistik und E-Mail-Vorlagen pro Kategorie/Sprache.';
$string['pro_settings_locked'] = 'Pro-Funktionen sind ohne gültige Lizenz deaktiviert.';
$string['webhook_url'] = 'Webhook-URL (ausgehend)';
$string['webhook_url_desc'] = 'Bei Anlegen, Ändern oder Absagen eines Termins wird ein JSON-POST an diese URL gesendet (Outlook/Google-Integration).';
$string['webhook_secret'] = 'Webhook-Geheimnis (optional)';
$string['webhook_secret_desc'] = 'Wenn gesetzt, wird der Header X-ZSK-Signature mit HMAC-SHA256 des JSON-Body gesendet.';
$string['ical_feed_url'] = 'iCal-Abonnement-URL';
$string['reminder_days_before'] = 'Erinnerung (Tage vor Terminbeginn)';
$string['reminder_days_before_desc'] = 'Pro: Erinnerungs-E-Mail für alle Termine am Kalendertag, der so viele Tage in der Zukunft liegt (z. B. 1 = morgen). Versand täglich per geplantem Task (8:15 Uhr).';

$string['notification_greeting'] = 'Hallo {$a},';
$string['notification_reminder_subject'] = 'Erinnerung: {$a}';
$string['notification_reminder_intro'] = 'Dies ist eine Erinnerung an den folgenden Termin:';
$string['notification_cancel_subject'] = 'Absage: {$a}';
$string['notification_cancel_intro'] = 'Der folgende Termin wurde abgesagt:';
$string['event_cancelled_notify_queued'] = 'Termin abgesagt. Absage-E-Mail an {$a} Empfänger wurde in die Warteschlange gestellt.';

$string['digest_heading'] = 'Neue Termine';

$string['category_email_templates'] = 'E-Mail-Vorlagen (Pro)';
$string['category_email_templates_help'] = 'Platzhalter: {title}, {datetime}, {category}, {location}, {course}, {description}, {link}, {userfirstname}, {userlastname}, {userfullname}. Leer lassen = Standardvorlage.';
$string['category_email_lang'] = 'Sprache: {$a}';
$string['category_email_subject'] = 'Betreff';
$string['category_email_bodyhtml'] = 'Nachricht (HTML)';
$string['category_email_bodyplain'] = 'Nachricht (Text)';

$string['stats_heading'] = 'E-Mail-Statistik';
$string['stats_summary'] = 'Gesamt';
$string['stats_sent'] = 'Gesendet';
$string['stats_opened'] = 'Geöffnet';
$string['stats_open_rate'] = 'Öffnungsrate';
$string['stats_clicked'] = 'Geklickt';
$string['stats_click_rate'] = 'Klickrate';
$string['stats_views'] = 'Seitenaufrufe';
$string['stats_per_event'] = 'Pro Termin';
$string['stats_no_data'] = 'Noch keine E-Mail-Daten vorhanden.';
