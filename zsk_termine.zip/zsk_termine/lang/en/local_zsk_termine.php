<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'ZSK Upcoming events';
$string['privacy:metadata'] = 'The Upcoming events plugin stores events and permissions.';

$string['nopermission'] = 'You do not have permission to perform this action.';

$string['upcoming_heading'] = 'Upcoming events';
$string['more_events'] = 'More events …';
$string['all_events'] = 'All events';
$string['all_categories'] = 'All categories';
$string['no_events'] = 'There are no upcoming events at the moment.';
$string['event_cancelled'] = 'Cancelled';

$string['manage_events'] = 'Manage events';
$string['manage_events_list'] = 'Event list (admin)';
$string['manage_categories'] = 'Manage categories';
$string['manageaccess'] = 'ZSK Termine permissions';
$string['manageaccess_desc'] = 'Choose which users may create, edit, cancel and delete events. Site administrators always have access.';
$string['manageaccess_saved'] = 'Permissions saved.';
$string['manageaccess_tables_missing'] = 'Permission tables are missing. Please run the plugin upgrade.';
$string['allowmanageusers'] = 'Authorised users';
$string['allowmanageusers_help'] = 'These users may manage events and categories (in addition to users with the manage capability).';

$string['add_event'] = 'Add event';
$string['edit_event'] = 'Edit event';
$string['delete_event'] = 'Delete event';
$string['delete_event_confirm'] = 'Delete event "{$a}"?';
$string['event_saved'] = 'Event saved.';
$string['event_deleted'] = 'Event deleted.';
$string['event_cancel_action'] = 'Cancel event';
$string['event_cancelled_done'] = 'Event marked as cancelled.';

$string['event_title'] = 'Title';
$string['event_category'] = 'Category';
$string['event_course'] = 'Course assignment';
$string['event_course_none'] = 'No course (site-wide)';
$string['event_course_help'] = 'Optionally assign to a course. The site home, dashboard and “My courses” show all upcoming events; the course activity shows only that course’s events.';
$string['event_timestart'] = 'Start';
$string['event_timeend'] = 'End';
$string['event_hasend'] = 'Specify end time';
$string['event_location'] = 'Location';
$string['event_description'] = 'Description';
$string['event_cancelled_field'] = 'Event is cancelled';
$string['event_highlighted'] = 'Highlight event with background colour';
$string['event_highlighted_help'] = 'The event is shown with a coloured background in lists and the preview block (e.g. for important events).';
$string['invalidevent'] = 'Unknown event.';
$string['no_categories'] = 'Please create at least one category first.';

$string['category_name'] = 'Category name';
$string['category_icon'] = 'Icon';
$string['category_icon_help'] = 'Moodle pix icon, e.g. i/calendar, i/cohort, i/group.';
$string['category_sortorder'] = 'Sort order';
$string['category_saved'] = 'Category saved.';
$string['category_deleted'] = 'Category deleted.';
$string['category_delete_confirm'] = 'Delete this category?';
$string['category_delete_blocked'] = 'Cannot delete category while events are assigned to it.';
$string['add_category'] = 'Add category';

$string['actions'] = 'Actions';
$string['settings'] = 'Settings';
$string['termine_settings'] = 'ZSK Termine – settings';
$string['admin_category_zsk_plugins'] = 'ZSK plugins';
$string['license_hub_title'] = 'ZSK plugin licenses';
$string['license_hub_shared_heading'] = 'Shared license server settings';
$string['license_hub_shared_desc'] = 'URL and offline grace apply to all ZSK plugins on this Moodle site.';
$string['license_hub_termine_heading'] = 'ZSK Termine';
$string['license_hub_other_heading'] = 'Other ZSK plugins';
$string['license_hub_other_desc'] = 'Licenses for additional ZSK plugins (e.g. Course Content Health Dashboard) will appear here once those plugins use this hub.';

$string['blocksettings_heading'] = 'Site home & Dashboard';
$string['blocksettings_intro'] = 'Site home: choose the element in front page settings. Dashboard: display in the centre of /my/ (no separate block plugin).';
$string['block_dashboard'] = 'Allow upcoming events on Dashboard (centre)';
$string['block_dashboard_desc'] = 'Shows upcoming events at the top of the dashboard centre column (/my/). No additional block plugin required.';
$string['block_frontpage'] = 'Allow upcoming events on site home (centre)';
$string['block_frontpage_desc'] = 'When “Upcoming events” is selected in front page settings, upcoming events are shown in the centre column.';
$string['block_frontpage_slot'] = 'Order on site home';
$string['block_frontpage_slot_desc'] = 'Site administration → Front page → Front page settings → “Front page items when logged in”: choose “Upcoming events” and set order relative to course tiles, course list, etc.';
$string['frontpagetermine'] = 'Upcoming events';
$string['frontpagetermine_heading'] = 'Upcoming events';
$string['block_preview_count'] = 'Number of events in preview';
$string['block_preview_count_desc'] = '3 or 4 events; link to full list when there are more.';
$string['block_position'] = 'Position relative to tiles';
$string['block_position_desc'] = 'Only applies when the tile view (local_tiles) is active on the same page.';
$string['block_position_before'] = 'Before tiles';
$string['block_position_after'] = 'After tiles';
$string['blocksettings_admin_hint'] = 'Settings: Site administration → Appearance → Site home & Dashboard.';

$string['accessmode'] = 'Management access';
$string['accessmode_desc'] = 'In addition to the user list you can assign the manage capability.';
$string['accessmode_allowlist'] = 'User list + administrators';
$string['accessmode_capability'] = 'Manage capability only (+ administrators)';

$string['notification_header'] = 'Email notification';
$string['notification_send'] = 'Send email notification when saving';
$string['notification_send_help'] = 'Only when creating a new event. Sending runs asynchronously via Moodle adhoc tasks (cron). Cancelled events are not announced by email.';
$string['notification_audience'] = 'Recipients';
$string['notification_audience_help'] = 'For site-wide events (no course), all active users with a valid email address are notified. For course events you can choose all users or enrolled users only.';
$string['notification_audience_all'] = 'All users on the site';
$string['notification_audience_enrolled'] = 'Enrolled users in the selected course only';
$string['notification_cancelled_conflict'] = 'A cancelled event cannot be announced by email.';
$string['event_saved_notify_queued'] = 'Event saved. Email notification queued for {$a} recipients.';
$string['notification_subject'] = 'New event: {$a}';
$string['notification_intro'] = 'A new event has been added:';
$string['notification_when'] = 'When: {$a}';
$string['notification_category'] = 'Category: {$a}';
$string['notification_location'] = 'Location: {$a}';
$string['notification_course'] = 'Course: {$a}';
$string['notification_viewlink'] = 'View event';
$string['notification_sender_fallback'] = 'Moodle learning platform';
$string['notification_settings_heading'] = 'Email notifications';
$string['notification_settings_desc'] = 'Optional email announcement when creating new events (new events only, not when editing).';
$string['notification_settings_enabled'] = 'Allow email notifications';
$string['notification_settings_enabled_desc'] = 'Shows the option to send an email when creating an event.';
$string['notification_settings_batchsize'] = 'Email send batch size';
$string['notification_settings_batchsize_desc'] = 'Recipients per background task (default: 50).';
$string['task_send_notification_batch'] = 'Events: send notification batch';

$string['license_heading'] = 'License (Pro / Premium)';
$string['license_heading_desc'] = 'License key for Pro features. Without a valid license the free tier limits apply.';
$string['license_key'] = 'Premium license key';
$string['license_key_desc'] = 'ZSK Termine key only (plugin local_zsk_termine). Create on the license server with: php cli/create_license.php --plugin=local_zsk_termine. Health Dashboard keys (ZSK-HD-…) will not work here.';
$string['license_status_key_unverified'] = 'License key saved but not verified – re-save the key or check the license server.';
$string['license_status_key_no_server'] = 'License key saved but no license server URL configured.';
$string['license_server_url'] = 'License server URL';
$string['license_server_url_desc'] = 'Full URL of the verify endpoint (e.g. http://your-server/zsk-license/api/v1/verify.php). No default preset.';
$string['license_status'] = 'License status';
$string['license_status_free'] = 'Free tier (max. 3 categories, 1 display position, max. 3 preview events, max. 2 authorised users, email to enrolled users only, max. 50)';
$string['license_status_premium'] = 'Premium (all Pro features active)';
$string['license_status_premium_slots'] = 'Premium ({$a->used}/{$a->max} environments bound)';
$string['license_status_enterprise'] = 'Enterprise (all features including add-ons)';
$string['license_status_enterprise_slots'] = 'Enterprise ({$a->used}/{$a->max} environments bound)';
$string['license_status_site_limit'] = 'All {$a} environment slots are in use – this instance is not licensed';
$string['license_status_grace'] = 'Premium (offline grace: {$a} days, license server unreachable)';
$string['license_status_expired'] = 'License expired – free tier';
$string['license_status_invalid'] = 'Invalid license key – free tier';
$string['license_status_site_mismatch'] = 'License key bound to another Moodle site – free tier';
$string['license_grace_days'] = 'Offline grace period (days)';
$string['license_grace_days_desc'] = 'When the license server is temporarily unreachable, premium remains active for this many days.';
$string['license_error_no_server'] = 'No license server URL configured.';
$string['license_error_network'] = 'License server unreachable and no valid offline grace period available.';
$string['license_error_expired'] = 'The license has expired.';
$string['license_error_invalid'] = 'The license key is invalid.';
$string['license_error_site_mismatch'] = 'This license key is already bound to another Moodle instance.';
$string['license_error_site_limit'] = 'All {$a} environment slots are already in use.';
$string['license_error_inactive'] = 'This license key has been deactivated.';
$string['license_error_plugin_mismatch'] = 'This license key is not valid for this plugin.';
$string['license_error_display_limit'] = 'The free tier allows only one display position at a time (site home or dashboard/my courses).';
$string['license_error_category_limit'] = 'The free tier allows at most {$a} categories.';
$string['license_category_limit_notice'] = 'Free tier: at most {$a} categories. Premium removes this limit.';
$string['license_error_allowlist_limit'] = 'The free tier allows at most {$a} authorised users.';
$string['license_allowlist_limit_notice'] = 'Free tier: at most {$a} authorised users. Premium removes this limit.';
$string['license_display_free_hint'] = '(Free tier: one position at a time only.)';
$string['freemium_branding'] = 'Events by ZSK Termine';
$string['notification_free_limit'] = 'Free tier: email to enrolled course users only (max. 50 recipients).';
$string['notification_free_site_disabled'] = 'Email notifications for site-wide events require Premium. For course events: enrolled users only (max. 50).';
$string['task_verify_license'] = 'Events: verify license';
$string['task_send_reminders'] = 'Events: send reminder emails';

$string['pro_feature_required'] = 'This feature requires Pro/Premium.';
$string['pro_settings_heading'] = 'Pro features';
$string['pro_settings_desc'] = 'Webhook, iCal feed, reminders, statistics and per-category/language email templates.';
$string['pro_settings_locked'] = 'Pro features are disabled without a valid license.';
$string['webhook_url'] = 'Webhook URL (outbound)';
$string['webhook_url_desc'] = 'JSON POST when an event is created, updated or cancelled (Outlook/Google integration).';
$string['webhook_secret'] = 'Webhook secret (optional)';
$string['webhook_secret_desc'] = 'If set, header X-ZSK-Signature contains HMAC-SHA256 of the JSON body.';
$string['ical_feed_url'] = 'iCal subscription URL';
$string['reminder_days_before'] = 'Reminder (days before start)';
$string['reminder_days_before_desc'] = 'Pro: reminder email for all events on the calendar day that many days ahead (e.g. 1 = tomorrow). Sent daily by scheduled task (08:15).';

$string['notification_greeting'] = 'Hello {$a},';
$string['notification_reminder_subject'] = 'Reminder: {$a}';
$string['notification_reminder_intro'] = 'This is a reminder for the following event:';
$string['notification_cancel_subject'] = 'Cancelled: {$a}';
$string['notification_cancel_intro'] = 'The following event has been cancelled:';
$string['event_cancelled_notify_queued'] = 'Event cancelled. Cancellation email queued for {$a} recipients.';

$string['digest_heading'] = 'New events';

$string['category_email_templates'] = 'Email templates (Pro)';
$string['category_email_templates_help'] = 'Placeholders: {title}, {datetime}, {category}, {location}, {course}, {description}, {link}, {userfirstname}, {userlastname}, {userfullname}. Leave empty to use the default template.';
$string['category_email_lang'] = 'Language: {$a}';
$string['category_email_subject'] = 'Subject';
$string['category_email_bodyhtml'] = 'Message (HTML)';
$string['category_email_bodyplain'] = 'Message (plain text)';

$string['stats_heading'] = 'Email statistics';
$string['stats_summary'] = 'Overall';
$string['stats_sent'] = 'Sent';
$string['stats_opened'] = 'Opened';
$string['stats_open_rate'] = 'Open rate';
$string['stats_clicked'] = 'Clicked';
$string['stats_click_rate'] = 'Click rate';
$string['stats_views'] = 'Page views';
$string['stats_per_event'] = 'Per event';
$string['stats_no_data'] = 'No email data yet.';
