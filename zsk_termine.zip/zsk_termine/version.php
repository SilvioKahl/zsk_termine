<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_zsk_termine';
$plugin->version   = 2025061104;
$plugin->requires  = 2022112800; // Moodle 4.1.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.3.4';
