<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/** Show events regardless of course assignment (admin lists). */
define('LOCAL_TERMINE_COURSE_ALL', -1);

/**
 * @return bool
 */
function local_zsk_termine_allow_manage_table_exists(): bool {
    global $DB;
    $manager = $DB->get_manager();
    return $manager->table_exists('local_zsk_termine_allow_manage');
}

/**
 * @param int|null $userid
 * @return bool
 */
function local_zsk_termine_user_can_manage(?int $userid = null): bool {
    global $USER, $DB;

    $userid = $userid ?? (int) $USER->id;
    if (is_siteadmin($userid)) {
        return true;
    }

    $context = context_system::instance();
    if (has_capability('local/zsk_termine:manage', $context, $userid)) {
        return true;
    }

    $accessmode = (int) get_config('local_zsk_termine', 'accessmode');
    if ($accessmode !== 1 && local_zsk_termine_allow_manage_table_exists()
        && $DB->record_exists('local_zsk_termine_allow_manage', ['userid' => $userid])) {
        return true;
    }

    return false;
}

/**
 * @return void
 */
function local_zsk_termine_require_manage(): void {
    if (!local_zsk_termine_user_can_manage()) {
        throw new moodle_exception('nopermission', 'local_zsk_termine');
    }
}

/**
 * @param int|null $userid
 * @return bool
 */
function local_zsk_termine_user_can_view(?int $userid = null): bool {
    global $USER;

    $userid = $userid ?? (int) $USER->id;
    if (!isloggedin() || isguestuser($userid)) {
        return false;
    }

    $context = context_system::instance();
    return has_capability('local/zsk_termine:view', $context, $userid)
        || local_zsk_termine_user_can_manage($userid);
}

/**
 * @return void
 */
function local_zsk_termine_require_view(): void {
    require_login();
    if (!local_zsk_termine_user_can_view()) {
        throw new moodle_exception('nopermission', 'local_zsk_termine');
    }
}

/**
 * @return bool
 */
function local_zsk_termine_should_show_navigation(): bool {
    if (!isloggedin() || isguestuser()) {
        return false;
    }
    return local_zsk_termine_user_can_manage();
}

/**
 * @return pix_icon
 */
function local_zsk_termine_get_navigation_pix_icon(): pix_icon {
    return new pix_icon('i/calendar', '');
}

/**
 * @return array<int,string>
 */
function local_zsk_termine_get_allowed_user_options(): array {
    global $DB;

    $options = [];
    if (!local_zsk_termine_allow_manage_table_exists()) {
        return $options;
    }

    $sql = "SELECT u.id, u.firstname, u.lastname, u.email
              FROM {user} u
              JOIN {local_zsk_termine_allow_manage} a ON a.userid = u.id
             WHERE u.deleted = 0
          ORDER BY u.lastname ASC, u.firstname ASC";
    foreach ($DB->get_records_sql($sql) as $user) {
        $options[(int) $user->id] = fullname($user) . ' (' . $user->email . ')';
    }

    return $options;
}

/**
 * @return int[]
 */
function local_zsk_termine_get_allow_manage_userids(): array {
    global $DB;

    if (!local_zsk_termine_allow_manage_table_exists()) {
        return [];
    }

    return array_map('intval', array_keys($DB->get_records('local_zsk_termine_allow_manage', null, '', 'userid, id')));
}

/**
 * @param int[] $userids
 * @return void
 */
function local_zsk_termine_set_allow_manage_userids(array $userids): void {
    global $DB;

    if (!local_zsk_termine_allow_manage_table_exists()) {
        return;
    }

    $userids = array_values(array_unique(array_filter(array_map('intval', $userids))));
    $max = \local_zsk_termine\util\license::get_max_allowlist_users();
    if ($max !== null && count($userids) > $max) {
        $userids = array_slice($userids, 0, $max);
    }
    $DB->delete_records('local_zsk_termine_allow_manage');
    $now = time();
    foreach ($userids as $userid) {
        if ($userid <= 0) {
            continue;
        }
        $DB->insert_record('local_zsk_termine_allow_manage', (object) [
            'userid' => $userid,
            'timecreated' => $now,
        ]);
    }
}

/**
 * @param int[] $userids
 * @return array<int,string>
 */
function local_zsk_termine_userids_to_options(array $userids): array {
    global $DB;

    $userids = array_values(array_unique(array_filter(array_map('intval', $userids))));
    if (empty($userids)) {
        return [];
    }

    [$insql, $params] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
    $users = $DB->get_records_select('user', "id {$insql} AND deleted = 0", $params);
    $options = [];
    foreach ($userids as $userid) {
        if (!isset($users[$userid])) {
            continue;
        }
        $user = $users[$userid];
        $options[$userid] = fullname($user) . ' (' . $user->email . ')';
    }

    return $options;
}

/**
 * Page context for the upcoming-events block: dashboard|frontpage|null.
 *
 * @return string|null
 */
function local_zsk_termine_get_block_page_context(): ?string {
    if (function_exists('local_tiles2_block_get_page_context')) {
        $ctx = local_tiles2_block_get_page_context();
        if ($ctx === 'dashboard' || $ctx === 'frontpage') {
            return $ctx;
        }
    }

    if (function_exists('local_tiles_get_tile_page_context')) {
        $ctx = local_tiles_get_tile_page_context();
    } else if (function_exists('local_statistics_get_tile_page_context')) {
        $ctx = local_statistics_get_tile_page_context();
    } else {
        $ctx = null;
    }
    if ($ctx === 'dashboard' || $ctx === 'frontpage') {
        return $ctx;
    }

    if (function_exists('local_tiles2_is_dashboard_request') && local_tiles2_is_dashboard_request()) {
        return 'dashboard';
    }
    if (function_exists('local_tiles_is_dashboard_request') && local_tiles_is_dashboard_request()) {
        return 'dashboard';
    }
    if (function_exists('local_statistics_is_dashboard_request')
        && local_statistics_is_dashboard_request()) {
        return 'dashboard';
    }

    if (function_exists('local_tiles2_is_site_frontpage') && local_tiles2_is_site_frontpage()) {
        return 'frontpage';
    }
    if (function_exists('local_tiles_is_site_frontpage') && local_tiles_is_site_frontpage()) {
        return 'frontpage';
    }
    if (function_exists('local_statistics_is_site_frontpage')
        && local_statistics_is_site_frontpage()) {
        return 'frontpage';
    }

    return null;
}

/**
 * @param string $context dashboard|frontpage
 * @return bool
 */
function local_zsk_termine_block_enabled_for(string $context): bool {
    $keys = [
        'dashboard' => 'block_dashboard',
        'frontpage' => 'block_frontpage',
    ];
    if (!isset($keys[$context])) {
        return false;
    }
    if (!(bool) get_config('local_zsk_termine', $keys[$context])) {
        return false;
    }

    if (!\local_zsk_termine\util\license::can_use_multiple_display_positions()) {
        $active = local_zsk_termine_get_active_display_contexts();
        return in_array($context, $active, true);
    }

    return true;
}

/**
 * Display contexts enabled in settings, respecting the free-tier single-position limit.
 *
 * @return string[] dashboard|frontpage
 */
function local_zsk_termine_get_active_display_contexts(): array {
    $contexts = [];
    if ((bool) get_config('local_zsk_termine', 'block_frontpage')) {
        $contexts[] = 'frontpage';
    }
    if ((bool) get_config('local_zsk_termine', 'block_dashboard')) {
        $contexts[] = 'dashboard';
    }

    if (!\local_zsk_termine\util\license::can_use_multiple_display_positions()) {
        return array_slice($contexts, 0, 1);
    }

    return $contexts;
}

/**
 * @return int
 */
function local_zsk_termine_get_block_preview_count(): int {
    $count = (int) get_config('local_zsk_termine', 'block_preview_count');
    if ($count < 3) {
        $count = 3;
    }
    $max = \local_zsk_termine\util\license::get_max_preview_count();
    if ($count > $max) {
        $count = $max;
    }
    return $count;
}

/**
 * @return string before|after
 */
function local_zsk_termine_get_block_position(): string {
    $pos = (string) get_config('local_zsk_termine', 'block_position');
    return $pos === 'after' ? 'after' : 'before';
}

/**
 * Course options for the event edit form (0 = site-wide).
 *
 * @return array<int,string>
 */
function local_zsk_termine_get_course_options(): array {
    global $DB;

    $options = [0 => get_string('event_course_none', 'local_zsk_termine')];
    $courses = $DB->get_records_select(
        'course',
        'id <> :siteid',
        ['siteid' => SITEID],
        'fullname ASC',
        'id, fullname, shortname'
    );

    foreach ($courses as $course) {
        $options[(int) $course->id] = format_string($course->fullname);
    }

    return $options;
}

/**
 * Rebuild course module cache when course-assigned events change (inline lists).
 *
 * @param int $courseid
 * @return void
 */
function local_zsk_termine_invalidate_course_display(int $courseid): void {
    if ($courseid <= 0) {
        return;
    }

    rebuild_course_cache($courseid);
}

/**
 * @param stdClass $event
 * @return string
 */
function local_zsk_termine_format_course_label(stdClass $event): string {
    global $DB;

    $courseid = (int) ($event->courseid ?? 0);
    if ($courseid <= 0) {
        return get_string('event_course_none', 'local_zsk_termine');
    }

    $fullname = $DB->get_field('course', 'fullname', ['id' => $courseid]);
    return $fullname ? format_string($fullname) : (string) $courseid;
}

/**
 * @param int|null $categoryid
 * @param int $limit 0 = no limit
 * @param bool $includepast
 * @param int|null $courseid 0/null = site-wide only, &gt;0 = one course, LOCAL_TERMINE_COURSE_ALL = all
 * @return stdClass[]
 */
function local_zsk_termine_get_upcoming_events(
    ?int $categoryid = null,
    int $limit = 0,
    bool $includepast = false,
    ?int $courseid = null
): array {
    global $DB;

    $now = time();
    $params = [];
    $where = '1=1';

    if (!$includepast) {
        $where .= ' AND ((e.timeend > 0 AND e.timeend >= :nowend) OR (COALESCE(e.timeend, 0) = 0 AND e.timestart >= :nowstart))';
        $params['nowend'] = $now;
        $params['nowstart'] = $now;
    }

    if ($categoryid !== null && $categoryid > 0) {
        $where .= ' AND e.categoryid = :categoryid';
        $params['categoryid'] = $categoryid;
    }

    if ($courseid === LOCAL_TERMINE_COURSE_ALL) {
        // No course filter (admin overview).
    } else if ($courseid !== null && $courseid > 0) {
        $where .= ' AND e.courseid = :courseid';
        $params['courseid'] = $courseid;
    } else {
        $where .= ' AND e.courseid = 0';
    }

    $sql = "SELECT e.*, c.name AS categoryname, c.icon AS categoryicon
              FROM {local_zsk_termine_event} e
              JOIN {local_zsk_termine_category} c ON c.id = e.categoryid
             WHERE {$where}
          ORDER BY e.timestart ASC";

    $records = $DB->get_records_sql($sql, $params, 0, $limit > 0 ? $limit : 0);

    return array_values($records);
}

/**
 * @param int $eventid
 * @return stdClass|null
 */
function local_zsk_termine_get_event(int $eventid): ?stdClass {
    global $DB;

    $sql = "SELECT e.*, c.name AS categoryname, c.icon AS categoryicon
              FROM {local_zsk_termine_event} e
              JOIN {local_zsk_termine_category} c ON c.id = e.categoryid
             WHERE e.id = :id";

    return $DB->get_record_sql($sql, ['id' => $eventid]) ?: null;
}

/**
 * @return stdClass[]
 */
function local_zsk_termine_get_categories(): array {
    global $DB;
    return $DB->get_records('local_zsk_termine_category', null, 'sortorder ASC, name ASC');
}

/**
 * Format event date/time for display.
 *
 * @param stdClass $event
 * @return string
 */
function local_zsk_termine_format_event_datetime(stdClass $event): string {
    $start = userdate($event->timestart, get_string('strftimedatetimeshort', 'langconfig'));
    if (!empty($event->timeend) && (int) $event->timeend > (int) $event->timestart) {
        $end = userdate($event->timeend, get_string('strftimetime', 'langconfig'));
        return $start . ' – ' . $end;
    }
    return $start;
}

/**
 * Template payload for one event row.
 *
 * @param stdClass $event
 * @return array
 */
function local_zsk_termine_event_to_template_item(stdClass $event): array {
    global $OUTPUT;

    $icon = trim($event->categoryicon ?? 'i/calendar');
    if ($icon === '') {
        $icon = 'i/calendar';
    }

    return [
        'title' => format_string($event->title),
        'datetime' => local_zsk_termine_format_event_datetime($event),
        'location' => !empty($event->location) ? format_string($event->location) : '',
        'haslocation' => !empty($event->location),
        'categoryname' => format_string($event->categoryname ?? ''),
        'cancelled' => !empty($event->cancelled),
        'cancelledlabel' => get_string('event_cancelled', 'local_zsk_termine'),
        'highlighted' => !empty($event->highlighted) && \local_zsk_termine\util\license::can_use_highlighted_events(),
        'iconhtml' => $OUTPUT->pix_icon($icon, $event->categoryname ?? '', 'moodle', ['class' => 'local-termine-icon']),
        'detailurl' => (new moodle_url('/local/zsk_termine/view.php', ['id' => (int) $event->id]))->out(false),
        'description' => !empty($event->description)
            ? format_text(
                $event->description,
                $event->descriptionformat ?? FORMAT_HTML,
                ['context' => context_system::instance()]
            )
            : '',
        'hasdescription' => !empty($event->description),
    ];
}

/**
 * Build upcoming-events block HTML for dashboard / front page (shared renderer).
 *
 * @return string
 */
function local_zsk_termine_render_upcoming_block_html(): string {
    if (!local_zsk_termine_user_can_view()) {
        return '';
    }

    $previewcount = local_zsk_termine_get_block_preview_count();
    $total = local_zsk_termine_count_upcoming_events(null, LOCAL_TERMINE_COURSE_ALL);
    if ($total === 0) {
        return '';
    }

    $events = local_zsk_termine_get_upcoming_events(null, $previewcount, false, LOCAL_TERMINE_COURSE_ALL);
    if (empty($events)) {
        return '';
    }

    return local_zsk_termine_render_block_html($events, $total, $previewcount);
}

/**
 * Register termine stylesheet in <head> or return a late <link> fallback.
 *
 * @return string
 */
function local_zsk_termine_require_styles(): string {
    global $PAGE;

    static $handled = false;
    if ($handled || empty($PAGE)) {
        return '';
    }

    $csspath = '/local/zsk_termine/styles.css';

    if (!$PAGE->requires->is_head_done()) {
        $PAGE->requires->css($csspath);
        $handled = true;
        return '';
    }

    $handled = true;
    $url = (new moodle_url($csspath))->out(false);

    return html_writer::empty_tag('link', [
        'rel' => 'stylesheet',
        'href' => $url,
        'data-local-termine' => '1',
    ]);
}

/**
 * Render HTML for the upcoming-events block.
 *
 * @param stdClass[] $events
 * @param int $totalcount
 * @param int $previewcount
 * @return string
 */
function local_zsk_termine_render_block_html(array $events, int $totalcount, int $previewcount): string {
    global $OUTPUT;

    if (empty($events)) {
        return '';
    }

    $moreurl = new moodle_url('/local/zsk_termine/index.php');
    $data = [
        'title' => get_string('upcoming_heading', 'local_zsk_termine'),
        'events' => [],
        'hasmore' => $totalcount > count($events),
        'moreurl' => $moreurl->out(false),
        'morelabel' => get_string('more_events', 'local_zsk_termine'),
        'manageurl' => '',
        'showmanage' => local_zsk_termine_user_can_manage(),
        'showbranding' => \local_zsk_termine\util\license::show_branding(),
        'brandinglabel' => get_string('freemium_branding', 'local_zsk_termine'),
    ];

    if ($data['showmanage']) {
        $data['manageurl'] = (new moodle_url('/local/zsk_termine/manage.php'))->out(false);
        $data['managelabel'] = get_string('manage_events', 'local_zsk_termine');
    }

    foreach ($events as $event) {
        $data['events'][] = local_zsk_termine_event_to_template_item($event);
    }

    return $OUTPUT->render_from_template('local_zsk_termine/upcoming_block', $data);
}

/**
 * Count upcoming events (same filter as get_upcoming_events).
 *
 * @param int|null $categoryid
 * @return int
 */
function local_zsk_termine_count_upcoming_events(?int $categoryid = null, ?int $courseid = null): int {
    global $DB;

    $now = time();
    $params = ['nowend' => $now, 'nowstart' => $now];
    $where = '((timeend > 0 AND timeend >= :nowend) OR (COALESCE(timeend, 0) = 0 AND timestart >= :nowstart))';

    if ($categoryid !== null && $categoryid > 0) {
        $where .= ' AND categoryid = :categoryid';
        $params['categoryid'] = $categoryid;
    }

    if ($courseid === LOCAL_TERMINE_COURSE_ALL) {
        // No course filter.
    } else if ($courseid !== null && $courseid > 0) {
        $where .= ' AND courseid = :courseid';
        $params['courseid'] = $courseid;
    } else {
        $where .= ' AND courseid = 0';
    }

    return $DB->count_records_select('local_zsk_termine_event', $where, $params);
}

/**
 * @deprecated Dashboard and site home use output hooks (see hook_callbacks).
 * @return void
 */
function local_zsk_termine_try_inject_block(): void {
    // Legacy JS injection removed – see hook_callbacks::inject_frontpage_termine() and inject_dashboard_termine().
}

/**
 * Render full event list (index / mod view).
 *
 * @param stdClass[] $events
 * @param int|null $categoryid
 * @return string
 */
function local_zsk_termine_render_event_list(array $events, ?int $categoryid = null): string {
    global $OUTPUT;

    $items = [];
    foreach ($events as $event) {
        $items[] = local_zsk_termine_event_to_template_item($event);
    }

    return $OUTPUT->render_from_template('local_zsk_termine/event_list', [
        'events' => $items,
        'empty' => empty($items),
        'emptytext' => get_string('no_events', 'local_zsk_termine'),
    ]);
}

/**
 * Whether another category may be created in the current license tier.
 *
 * @return bool
 */
function local_zsk_termine_can_add_category(): bool {
    global $DB;

    $max = \local_zsk_termine\util\license::get_max_categories();
    if ($max === null) {
        return true;
    }

    return $DB->count_records('local_zsk_termine_category') < $max;
}

/**
 * Whether event notification emails are enabled in plugin settings.
 *
 * @return bool
 */
function local_zsk_termine_notifications_enabled(): bool {
    return \local_zsk_termine\util\license::can_send_course_notifications();
}

/**
 * Batch size for notification adhoc tasks.
 *
 * @return int
 */
function local_zsk_termine_notification_batch_size(): int {
    $size = (int) get_config('local_zsk_termine', 'notify_batchsize');
    return $size > 0 ? $size : 50;
}

/**
 * Queue notification emails for a newly created event.
 *
 * @param int $eventid
 * @param string $audience \local_zsk_termine\notification\recipient_resolver::AUDIENCE_*
 * @return int Number of recipients queued (0 if none).
 */
function local_zsk_termine_queue_event_notification(
    int $eventid,
    string $audience,
    string $sendtype = \local_zsk_termine\notification\template_resolver::SENDTYPE_NEW
): int {
    if (!local_zsk_termine_notifications_enabled()) {
        return 0;
    }

    if ($sendtype === \local_zsk_termine\notification\template_resolver::SENDTYPE_REMINDER
        && !\local_zsk_termine\util\license::can_send_reminder_emails()) {
        return 0;
    }

    if ($sendtype === \local_zsk_termine\notification\template_resolver::SENDTYPE_CANCEL
        && !\local_zsk_termine\util\license::can_send_cancellation_emails()) {
        return 0;
    }

    $event = local_zsk_termine_get_event($eventid);
    if (!$event) {
        return 0;
    }

    if ($sendtype !== \local_zsk_termine\notification\template_resolver::SENDTYPE_CANCEL && !empty($event->cancelled)) {
        return 0;
    }

    $courseid = (int) ($event->courseid ?? 0);
    if (!\local_zsk_termine\util\license::can_send_notifications_for_event($courseid)) {
        return 0;
    }

    if (!\local_zsk_termine\util\license::can_notify_all_users()) {
        $audience = \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ENROLLED;
        if ($courseid <= 0) {
            return 0;
        }
    } else if ($courseid <= 0) {
        $audience = \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ALL;
    } else if ($audience !== \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ENROLLED) {
        $audience = \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ALL;
    }

    $userids = \local_zsk_termine\notification\recipient_resolver::get_recipient_ids($courseid, $audience);
    if (empty($userids)) {
        return 0;
    }

    $maxrecipients = \local_zsk_termine\util\license::get_max_email_recipients();
    if ($maxrecipients !== null && count($userids) > $maxrecipients) {
        $userids = array_slice($userids, 0, $maxrecipients);
    }

    $batchsize = local_zsk_termine_notification_batch_size();
    foreach (array_chunk($userids, $batchsize) as $chunk) {
        $task = new \local_zsk_termine\task\send_notification_batch();
        $task->set_custom_data((object) [
            'eventid' => $eventid,
            'sendtype' => $sendtype,
            'userids' => $chunk,
        ]);
        \core\task\manager::queue_adhoc_task($task);
    }

    return count($userids);
}

/**
 * Queue cancellation notification emails (Pro).
 *
 * @param int $eventid
 * @return int
 */
function local_zsk_termine_queue_cancellation_notification(int $eventid): int {
    $event = local_zsk_termine_get_event($eventid);
    if (!$event) {
        return 0;
    }

    $courseid = (int) ($event->courseid ?? 0);
    $audience = $courseid > 0
        ? \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ENROLLED
        : \local_zsk_termine\notification\recipient_resolver::AUDIENCE_ALL;

    return local_zsk_termine_queue_event_notification(
        $eventid,
        $audience,
        \local_zsk_termine\notification\template_resolver::SENDTYPE_CANCEL
    );
}

/**
 * Build digest section for local_zsk_local_newsletter (Pro).
 *
 * @param int $since Unix timestamp.
 * @return array{html: string, plain: string, hascontent: bool}
 */
function local_zsk_termine_digest_build_section(int $since): array {
    if (!\local_zsk_termine\util\license::can_use_digest()) {
        return ['html' => '', 'plain' => '', 'hascontent' => false];
    }

    $events = local_zsk_termine_get_upcoming_events(null, 20, false, LOCAL_TERMINE_COURSE_ALL);
    $newevents = array_filter($events, function ($event) use ($since) {
        return (int) ($event->timecreated ?? 0) >= $since;
    });

    if (empty($newevents)) {
        return ['html' => '', 'plain' => '', 'hascontent' => false];
    }

    $html = html_writer::tag('h3', get_string('digest_heading', 'local_zsk_termine'));
    $plain = get_string('digest_heading', 'local_zsk_termine') . "\n\n";
    $html .= html_writer::start_tag('ul');
    foreach ($newevents as $event) {
        $url = (new moodle_url('/local/zsk_termine/view.php', ['id' => $event->id]))->out(false);
        $line = format_string($event->title) . ' – ' . local_zsk_termine_format_event_datetime($event);
        $html .= html_writer::tag('li', html_writer::link($url, $line));
        $plain .= '- ' . $line . ' ' . $url . "\n";
    }
    $html .= html_writer::end_tag('ul');

    return [
        'html' => $html,
        'plain' => $plain,
        'hascontent' => true,
    ];
}

/**
 * Build iCal VCALENDAR content.
 *
 * @param int|null $categoryid
 * @param int|null $courseid
 * @return string
 */
function local_zsk_termine_build_ical_feed(?int $categoryid = null, ?int $courseid = 0): string {
    global $CFG;

    $coursefilter = $courseid === null ? LOCAL_TERMINE_COURSE_ALL : (int) $courseid;
    $events = local_zsk_termine_get_upcoming_events($categoryid, 500, false, $coursefilter);

    $lines = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//ZSK Termine//Moodle//EN',
        'CALSCALE:GREGORIAN',
        'METHOD:PUBLISH',
        'X-WR-CALNAME:' . local_zsk_termine_ical_escape(get_string('pluginname', 'local_zsk_termine')),
    ];

    foreach ($events as $event) {
        $uid = 'zsk-termine-' . $event->id . '@' . parse_url($CFG->wwwroot, PHP_URL_HOST);
        $dtstart = gmdate('Ymd\THis\Z', (int) $event->timestart);
        $dtend = !empty($event->timeend)
            ? gmdate('Ymd\THis\Z', (int) $event->timeend)
            : gmdate('Ymd\THis\Z', (int) $event->timestart + HOURSECS);

        $lines[] = 'BEGIN:VEVENT';
        $lines[] = 'UID:' . $uid;
        $lines[] = 'DTSTAMP:' . gmdate('Ymd\THis\Z');
        $lines[] = 'DTSTART:' . $dtstart;
        $lines[] = 'DTEND:' . $dtend;
        $lines[] = 'SUMMARY:' . local_zsk_termine_ical_escape(format_string($event->title));
        if (!empty($event->location)) {
            $lines[] = 'LOCATION:' . local_zsk_termine_ical_escape($event->location);
        }
        if (!empty($event->cancelled)) {
            $lines[] = 'STATUS:CANCELLED';
        }
        $lines[] = 'URL:' . (new moodle_url('/local/zsk_termine/view.php', ['id' => $event->id]))->out(false);
        $lines[] = 'END:VEVENT';
    }

    $lines[] = 'END:VCALENDAR';

    return implode("\r\n", $lines) . "\r\n";
}

/**
 * @param string $text
 * @return string
 */
function local_zsk_termine_ical_escape(string $text): string {
    $text = str_replace(['\\', ';', ',', "\n", "\r"], ['\\\\', '\\;', '\\,', '\\n', ''], $text);
    return $text;
}

/**
 * Ensure iCal feed token exists (Pro).
 *
 * @return string
 */
function local_zsk_termine_ensure_ical_feed_token(): string {
    $token = (string) get_config('local_zsk_termine', 'ical_feed_token');
    if ($token === '' && \local_zsk_termine\util\license::can_use_webhook()) {
        $token = bin2hex(random_bytes(16));
        set_config('ical_feed_token', $token, 'local_zsk_termine');
    }
    return $token;
}

/**
 * Save per-language email templates for a category.
 *
 * @param int $categoryid
 * @param string $lang
 * @param string $subject
 * @param string $bodyhtml
 * @param string $bodyplain
 * @return void
 */
function local_zsk_termine_save_category_lang_template(
    int $categoryid,
    string $lang,
    string $subject,
    string $bodyhtml,
    string $bodyplain
): void {
    global $DB;

    if (!\local_zsk_termine\util\license::can_use_category_email_templates()) {
        return;
    }

    if (!$DB->get_manager()->table_exists('local_zsk_termine_category_lang')) {
        return;
    }

    $record = $DB->get_record('local_zsk_termine_category_lang', [
        'categoryid' => $categoryid,
        'lang' => $lang,
    ]);

    $data = (object) [
        'categoryid' => $categoryid,
        'lang' => $lang,
        'notify_subject' => $subject,
        'notify_bodyhtml' => $bodyhtml,
        'notify_bodyplain' => $bodyplain,
        'timemodified' => time(),
    ];

    if ($record) {
        $data->id = $record->id;
        $DB->update_record('local_zsk_termine_category_lang', $data);
    } else {
        $DB->insert_record('local_zsk_termine_category_lang', $data);
    }
}

/**
 * @param int $categoryid
 * @return \stdClass[] keyed by lang
 */
function local_zsk_termine_get_category_lang_templates(int $categoryid): array {
    global $DB;

    if (!$DB->get_manager()->table_exists('local_zsk_termine_category_lang')) {
        return [];
    }

    $templates = [];
    foreach ($DB->get_records('local_zsk_termine_category_lang', ['categoryid' => $categoryid]) as $record) {
        $templates[$record->lang] = $record;
    }

    return $templates;
}
