<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_termine_require_manage();

$id = required_param('id', PARAM_INT);

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_termine/delete.php', ['id' => $id]));
$PAGE->set_pagelayout('admin');

$event = local_zsk_termine_get_event($id);
if (!$event) {
    throw new moodle_exception('invalidevent', 'local_zsk_termine');
}

global $DB;

if ($confirm = optional_param('confirm', 0, PARAM_INT)) {
    require_sesskey();
    $DB->delete_records('local_zsk_termine_event', ['id' => $id]);
    if (!empty($event->courseid)) {
        local_zsk_termine_invalidate_course_display((int) $event->courseid);
    }
    redirect(
        new moodle_url('/local/zsk_termine/events.php'),
        get_string('event_deleted', 'local_zsk_termine'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$PAGE->set_title(get_string('delete_event', 'local_zsk_termine'));
$PAGE->set_heading(get_string('delete_event', 'local_zsk_termine'));

echo $OUTPUT->header();
echo $OUTPUT->confirm(
    get_string('delete_event_confirm', 'local_zsk_termine', format_string($event->title)),
    new moodle_url('/local/zsk_termine/delete.php', ['id' => $id, 'confirm' => 1, 'sesskey' => sesskey()]),
    new moodle_url('/local/zsk_termine/events.php')
);
echo $OUTPUT->footer();
