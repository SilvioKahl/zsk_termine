<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_termine_require_view();

$id = required_param('id', PARAM_INT);
$event = local_zsk_termine_get_event($id);
if (!$event) {
    throw new moodle_exception('invalidevent', 'local_zsk_termine');
}

global $USER;
if (\local_zsk_termine\util\license::can_use_stats() && isloggedin() && !isguestuser()) {
    \local_zsk_termine\notification\tracker::log_stat($id, (int) $USER->id, 'view');
}

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_termine/view.php', ['id' => $id]));
$PAGE->set_pagelayout('standard');
$PAGE->set_title(format_string($event->title));
$PAGE->set_heading(format_string($event->title));
$PAGE->requires->css('/local/zsk_termine/styles.css');

$icon = trim($event->categoryicon ?? 'i/calendar') ?: 'i/calendar';

echo $OUTPUT->header();

echo html_writer::div(
    html_writer::link(new moodle_url('/local/zsk_termine/index.php'), '« ' . get_string('all_events', 'local_zsk_termine')),
    'mb-3'
);

if (local_zsk_termine_user_can_manage()) {
    echo html_writer::div(
        html_writer::link(new moodle_url('/local/zsk_termine/edit.php', ['id' => $id]), get_string('edit')) .
        ' | ' .
        html_writer::link(new moodle_url('/local/zsk_termine/events.php'), get_string('manage_events_list', 'local_zsk_termine')),
        'mb-3'
    );
}

$detailclass = 'local-termine-detail';
if (!empty($event->highlighted)) {
    $detailclass .= ' local-termine-highlighted';
}
echo html_writer::start_div($detailclass);
echo $OUTPUT->pix_icon($icon, '', 'moodle', ['class' => 'local-termine-icon mr-2']);
echo html_writer::tag('span', format_string($event->categoryname), ['class' => 'text-muted']);
echo html_writer::tag('p', local_zsk_termine_format_event_datetime($event), ['class' => 'lead mt-2']);
if (!empty($event->location)) {
    echo html_writer::tag('p', get_string('event_location', 'local_zsk_termine') . ': ' . format_string($event->location));
}
if (!empty($event->cancelled)) {
    echo $OUTPUT->notification(get_string('event_cancelled', 'local_zsk_termine'), 'warning');
}
if (!empty($event->description)) {
    echo format_text($event->description, $event->descriptionformat, ['context' => $context]);
}
echo html_writer::end_div();

echo $OUTPUT->footer();
