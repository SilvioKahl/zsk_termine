<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_termine_require_view();

$categoryid = optional_param('categoryid', 0, PARAM_INT);

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_termine/index.php', ['categoryid' => $categoryid]));
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('all_events', 'local_zsk_termine'));
$PAGE->set_heading(get_string('all_events', 'local_zsk_termine'));
$PAGE->requires->css('/local/zsk_termine/styles.css');

$events = local_zsk_termine_get_upcoming_events(
    $categoryid > 0 ? $categoryid : null,
    0,
    false,
    LOCAL_TERMINE_COURSE_ALL
);

echo $OUTPUT->header();

if (local_zsk_termine_user_can_manage()) {
    echo html_writer::div(
        html_writer::link(new moodle_url('/local/zsk_termine/manage.php'), '« ' . get_string('manage_events', 'local_zsk_termine')),
        'mb-3'
    );
}

$cats = local_zsk_termine_get_categories();
if (count($cats) > 1) {
    $links = [];
    $links[] = html_writer::link(
        new moodle_url('/local/zsk_termine/index.php'),
        get_string('all_categories', 'local_zsk_termine'),
        $categoryid === 0 ? ['class' => 'font-weight-bold'] : []
    );
    foreach ($cats as $cat) {
        $links[] = html_writer::link(
            new moodle_url('/local/zsk_termine/index.php', ['categoryid' => $cat->id]),
            format_string($cat->name),
            (int) $categoryid === (int) $cat->id ? ['class' => 'font-weight-bold'] : []
        );
    }
    echo html_writer::div(implode(' | ', $links), 'mb-3 local-termine-filters');
}

echo local_zsk_termine_render_event_list($events, $categoryid > 0 ? $categoryid : null);

echo $OUTPUT->footer();
