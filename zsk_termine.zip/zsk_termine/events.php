<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_termine_require_manage();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_termine/events.php'));
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('manage_events_list', 'local_zsk_termine'));
$PAGE->set_heading(get_string('manage_events_list', 'local_zsk_termine'));

$events = local_zsk_termine_get_upcoming_events(null, 0, true, LOCAL_TERMINE_COURSE_ALL);

echo $OUTPUT->header();
echo html_writer::div(
    html_writer::link(new moodle_url('/local/zsk_termine/manage.php'), '« ' . get_string('manage_events', 'local_zsk_termine')),
    'mb-3'
);
echo html_writer::div(
    html_writer::link(new moodle_url('/local/zsk_termine/edit.php'), get_string('add_event', 'local_zsk_termine'), ['class' => 'btn btn-primary mb-3'])
);

$table = new html_table();
$table->head = [
    get_string('event_title', 'local_zsk_termine'),
    get_string('event_category', 'local_zsk_termine'),
    get_string('event_course', 'local_zsk_termine'),
    get_string('event_timestart', 'local_zsk_termine'),
    get_string('actions', 'local_zsk_termine'),
];
$table->data = [];

foreach ($events as $event) {
    $actions = [];
    $actions[] = html_writer::link(
        new moodle_url('/local/zsk_termine/edit.php', ['id' => $event->id]),
        get_string('edit')
    );
    if (empty($event->cancelled)) {
        $actions[] = html_writer::link(
            new moodle_url('/local/zsk_termine/cancel.php', ['id' => $event->id, 'sesskey' => sesskey()]),
            get_string('event_cancel_action', 'local_zsk_termine')
        );
    }
    $actions[] = html_writer::link(
        new moodle_url('/local/zsk_termine/delete.php', ['id' => $event->id]),
        get_string('delete')
    );

    $table->data[] = [
        format_string($event->title)
            . (empty($event->cancelled) ? '' : ' (' . get_string('event_cancelled', 'local_zsk_termine') . ')')
            . (!empty($event->highlighted) ? ' ★' : ''),
        format_string($event->categoryname),
        local_zsk_termine_format_course_label($event),
        local_zsk_termine_format_event_datetime($event),
        implode(' | ', $actions),
    ];
}

if (empty($table->data)) {
    echo $OUTPUT->notification(get_string('no_events', 'local_zsk_termine'), 'info');
} else {
    echo html_writer::table($table);
}

echo $OUTPUT->footer();
