<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_termine_require_manage();
require_sesskey();

$id = required_param('id', PARAM_INT);
global $DB;

$event = $DB->get_record('local_zsk_termine_event', ['id' => $id], '*', MUST_EXIST);
$event->cancelled = 1;
$event->timemodified = time();
$DB->update_record('local_zsk_termine_event', $event);

$notifyqueued = local_zsk_termine_queue_cancellation_notification($id);
\local_zsk_termine\webhook\dispatcher::dispatch($id, \local_zsk_termine\webhook\dispatcher::ACTION_CANCELLED);

if (!empty($event->courseid)) {
    local_zsk_termine_invalidate_course_display((int) $event->courseid);
}

$message = $notifyqueued > 0
    ? get_string('event_cancelled_notify_queued', 'local_zsk_termine', $notifyqueued)
    : get_string('event_cancelled_done', 'local_zsk_termine');

redirect(
    new moodle_url('/local/zsk_termine/events.php'),
    $message,
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
