<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$token = required_param('token', PARAM_ALPHANUMEXT);

if (!\local_zsk_termine\util\license::can_use_webhook()) {
    throw new moodle_exception('pro_feature_required', 'local_zsk_termine');
}

$expected = (string) get_config('local_zsk_termine', 'ical_feed_token');
if ($expected === '' || !hash_equals($expected, $token)) {
    throw new moodle_exception('invalidtoken', 'error');
}

$ical = local_zsk_termine_build_ical_feed(null, LOCAL_TERMINE_COURSE_ALL);

header('Content-Type: text/calendar; charset=utf-8');
header('Content-Disposition: attachment; filename="zsk-termine.ics"');
header('Cache-Control: no-cache, must-revalidate');
echo $ical;
die();
